# Drawbacks and limitations (be upfront about these)

## Verification
1. **Simulation only.** Nothing was run on an FPGA, a real fan, or a real sensor. The fan is a simple software model.
2. **One author.** The RTL, reference model and testbenches share the same reading of the spec. A shared misunderstanding would pass everywhere. The AXI behaviour was not checked with an independent bus-protocol checker or third-party master.
3. **Clock-domain crossing is not proven.** Zero-delay simulation cannot show metastability or bit skew. The handshake is a standard, textbook scheme and has a stress test, but a CDC lint tool and static timing analysis are still needed.
4. **Coverage is code coverage only.** Line 98.7 %, branch 97.4 %, toggle 83.2 % (see COVERAGE.md). Functional coverage (mode x fault crosses), FSM-transition coverage and assertions were not measured. Covered does not mean checked.
5. **Bug injection is limited.** 22 hand-picked bugs were injected and 21 were caught. The survivor (mutant 13) removes only the 'stop integrating while saturated' term; the integrator is still clamped to the output range, so the behaviour is almost identical (a near-equivalent mutant). Catching 21 shows the tests have teeth but is not proof of zero bugs.
6. **Tools.** Only free tools were used (Icarus Verilog, Verilator, Yosys). No commercial simulator or formal tool was run.

## Design
7. **No clock speed or area figures.** Yosys gave a generic gate count (32,169), not tied to any FPGA or silicon process. No timing analysis was done.
8. **Single shared reset assumed** for both clock domains (the handshake starts with equal state).
9. **4-bit command counters** (fault clear, watchdog kick, telemetry clear): sixteen commands inside one bus-to-PWM transfer would alias to "no change".
10. **Hardware-sensor start-up:** the first temperature sample can be off by up to the hysteresis amount until a larger change arrives.
11. **Write lock is a software key** (0xA5 / 0x5A), not hardware-protected.
12. **External fault latency is 5 PCLK cycles** (2-flop sync + latch + safe flag + output flop). Internal faults take 1 flop. It is not a same-cycle brake.
13. **Quantised RPM.** RPM resolution equals the multiplier (30 RPM at a 1 s window, 2 pulses per revolution). Short windows are noisy.
14. **Fixed 4-point curve**, 8-bit temperature, one tach input, one fan loop (channel 0). Channels 1 to 7 are manual.
15. **Not implemented:** PWM dithering for extra resolution, APB/Wishbone wrappers, ECC/parity on registers, clock gating, scan/DFT insertion.
16. **Simulation timing is scaled.** One simulated "second" of fan time is 20,000 PCLK cycles, so closed-loop plots are in compressed time.

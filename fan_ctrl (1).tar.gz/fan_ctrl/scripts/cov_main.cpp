// Minimal Verilator driver that runs a timing testbench to $finish and then writes coverage data.
#include "VTOP.h"
#include "verilated.h"
#include "verilated_cov.h"
int main(int argc, char** argv) {
    VerilatedContext* ctx = new VerilatedContext;
    ctx->commandArgs(argc, argv);
    VTOP* top = new VTOP{ctx};
    while (!ctx->gotFinish()) {
        top->eval();
        if (!top->eventsPending()) break;
        ctx->time(top->nextTimeSlot());
    }
    top->final();
    ctx->coveragep()->write("cov.dat");
    delete top; delete ctx;
    return 0;
}

#!/usr/bin/env python3
"""Parse Verilator coverage.dat files -> per-file line & toggle coverage for rtl/*.v.
 strict : one point per INSTANCE (hierarchy kept), sys testbench alone
 union  : a point (file,line,item) counts as covered if hit in ANY instance of ANY testbench"""
import re, sys, os, collections
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
runs = {n: f"{R}/build/cov/{n}/cov.dat" for n in ("pwm", "cdc", "sys")}

def parse(path):
    pts = []
    for ln in open(path, errors="replace"):
        if not ln.startswith("C '"): continue
        body, cnt = ln[3:].rsplit("' ", 1)
        f = {}
        for part in body.split("\x01"):
            if "\x02" in part:
                k, v = part.split("\x02", 1); f[k] = v
        f["cnt"] = int(cnt)
        pts.append(f)
    return pts

def kind(p):
    pg = p.get("page", "")
    if pg.startswith("v_toggle"): return "toggle"
    if pg.startswith("v_line"):   return "line"
    if pg.startswith("v_branch"): return "branch"
    return None

def pct(h, n): return 100.0 * h / n if n else 100.0

data = {n: parse(p) for n, p in runs.items()}
files = sorted({p["f"] for pts in data.values() for p in pts if p.get("f", "").startswith("rtl/") and p["f"].endswith(".v")})

KINDS = ("line", "branch", "toggle")
strict = collections.defaultdict(lambda: {k: [0, 0] for k in KINDS})
for p in data["sys"]:
    k = kind(p); f = p.get("f", "")
    if k and f in files:
        strict[f][k][1] += 1; strict[f][k][0] += p["cnt"] > 0
un = collections.defaultdict(dict)
for n, pts in data.items():
    for p in pts:
        k = kind(p); f = p.get("f", "")
        if not k or f not in files: continue
        key = (k, p.get("l"), p.get("n"), p.get("o"), p.get("page"))
        un[f][key] = un[f].get(key, False) or p["cnt"] > 0

def un_counts(f, k):
    v = [x for kk, x in un[f].items() if kk[0] == k]
    return [sum(v), len(v)]

hdr = f"{'file':20s}" + "".join(f"{k+'% U':>11s}{k+'% S':>11s}" for k in KINDS)
out = ["U = union over all testbenches & instances   S = strict: full-system testbench, every instance counted separately", hdr]
tot = {(m, k): [0, 0] for m in "US" for k in KINDS}
for f in files:
    row = f"{os.path.basename(f):20s}"
    for k in KINDS:
        u, st = un_counts(f, k), strict[f][k]
        for m, v in (("U", u), ("S", st)):
            tot[(m, k)][0] += v[0]; tot[(m, k)][1] += v[1]
        row += f"{pct(*u):10.1f}%{pct(*st):10.1f}%"
    out.append(row)
out.append("-" * len(hdr))
row = f"{'TOTAL':20s}"
for k in KINDS:
    row += f"{pct(*tot[('U', k)]):10.1f}%{pct(*tot[('S', k)]):10.1f}%"
out.append(row)
out.append("points: " + ", ".join(f"{m}-{k}={tot[(m, k)][1]}" for m in "US" for k in KINDS))
if any(tot[(m, k)][1] == 0 for m in "US" for k in KINDS):
    sys.exit("ERROR: zero coverage points parsed - parser/format problem")
print("\n".join(out))
open(f"{R}/docs/coverage_summary.txt", "w").write("\n".join(out) + "\n")

miss = collections.defaultdict(lambda: collections.defaultdict(set))
for f in files:
    for key, v in un[f].items():
        if not v: miss[f][key[0]].add(int(key[1]))
with open(f"{R}/docs/coverage_uncovered.txt", "w") as fh:
    fh.write("Source lines with an uncovered point (union of all testbenches)\n")
    for f in files:
        fh.write(f"{f}\n")
        for k in KINDS: fh.write(f"   {k:7s}: {sorted(miss[f][k])}\n")

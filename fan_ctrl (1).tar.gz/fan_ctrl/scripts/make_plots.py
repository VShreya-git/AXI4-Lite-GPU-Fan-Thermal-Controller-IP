#!/usr/bin/env python3
"""Plots built from the REAL simulation output (build/wave.csv, build/series.csv)."""
import csv, os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.makedirs(f"{R}/docs", exist_ok=True)

# ---------- Fig 1: PWM pin waveforms ----------
rows = list(csv.DictReader(open(f"{R}/build/wave.csv")))
titles = ["Edge-aligned: 4 channels (25 / 50 / 75 / 25 % + phase offset on CH3)",
          "Center-aligned: same duties (symmetric pulses)",
          "Complementary pair with dead time = 4 cycles (CH0 high-side, CH1 low-side)"]
fig, axs = plt.subplots(3, 1, figsize=(11, 9))
for s, ax in enumerate(axs):
    d = [r for r in rows if int(r["scen"]) == s][:130]
    x = [int(r["cycle"]) for r in d]
    for ch in range(4):
        y = [int(r[f"p{ch}"]) + 1.4 * (3 - ch) for r in d]
        ax.step(x, y, where="post", label=f"CH{ch}")
    fr = [int(r["cycle"]) for r in d if r["frame"] == "1"]
    for f in fr: ax.axvline(f, color="gray", ls=":", lw=0.8)
    ax.set_title(titles[s], fontsize=10); ax.set_yticks([]); ax.set_xlabel("PCLK cycle")
    ax.legend(loc="upper right", ncol=4, fontsize=8)
    if s == 2:
        ov = sum(1 for r in [r for r in rows if int(r["scen"]) == 2] if r["p0"] == "1" and r["p1"] == "1")
        ax.text(0.01, 0.04, f"overlap cycles (both high): {ov}", transform=ax.transAxes, fontsize=9)
plt.tight_layout(); plt.savefig(f"{R}/docs/fig1_pwm_waveforms.png", dpi=130); plt.close()

# ---------- load time series ----------
S = list(csv.DictReader(open(f"{R}/build/series.csv")))
def col(ph, k): return [float(r[k]) for r in S if int(r["phase"]) == ph]

# ---------- Fig 2: closed-loop PI ----------
t = col(7, "t_us"); t0 = t[0]; t = [(x - t0) / 1000.0 for x in t]     # ms
fig, ax = plt.subplots(2, 1, figsize=(11, 7), sharex=True)
ax[0].plot(t, col(7, "target"), "k--", label="target RPM")
ax[0].plot(t, col(7, "rpm_plant"), color="tab:blue", alpha=.5, label="actual fan RPM (plant model)")
ax[0].step(t, col(7, "rpm_meas"), where="post", color="tab:red", label="measured RPM (tach, 1 s window)")
ax[0].set_ylabel("RPM"); ax[0].legend(fontsize=8); ax[0].grid(alpha=.3)
ax[0].set_title("Closed-loop PI: fan is 20 % weaker than assumed, then much weaker (saturation), then recovers")
ax[1].plot(t, [d / 65535 * 100 for d in col(7, "duty")], color="tab:green")
ax[1].set_ylabel("duty command (%)"); ax[1].set_xlabel("simulated time (ms, 1 s of fan time = 0.26 ms)"); ax[1].grid(alpha=.3)
ax[1].set_ylim(0, 105)
plt.tight_layout(); plt.savefig(f"{R}/docs/fig2_closed_loop.png", dpi=130); plt.close()

# ---------- Fig 3: fan curve (sweep up and down) ----------
W = list(csv.DictReader(open(f"{R}/build/sweep.csv")))
pts = [(30, 0x4000), (45, 0x8000), (60, 0xC000), (75, 0xFFFF)]
xs = [0, 30] + [p[0] for p in pts[1:]] + [100]
ys = [pts[0][1]] * 2 + [p[1] for p in pts[1:]] + [pts[-1][1]]
fig, ax = plt.subplots(figsize=(8.5, 5.2))
ax.plot(xs, [y / 65535 * 100 for y in ys], "k--", lw=1.2, label="programmed 4-point curve")
for d, c, m in (("up", "tab:red", "^"), ("down", "tab:blue", "v")):
    r = [x for x in W if x["dir"] == d]
    ax.scatter([int(x["temp_in"]) for x in r], [int(x["duty"]) / 65535 * 100 for x in r], s=12, color=c, marker=m,
               label=f"measured, temperature {'rising' if d == 'up' else 'falling'} (1 C steps)", zorder=3)
ax.set_xlabel("sensor temperature (C)"); ax.set_ylabel("fan duty (%)"); ax.grid(alpha=.3); ax.legend(fontsize=8)
ax.set_title("Temperature -> duty curve with 2 C deadband hysteresis")
plt.tight_layout(); plt.savefig(f"{R}/docs/fig3_fan_curve.png", dpi=130); plt.close()

# ---------- Fig 4: fault response ----------
t = col(8, "t_us"); t0 = t[0]; t = [(x - t0) / 1000.0 for x in t]
flt = [int(x) for x in col(8, "flt")]; safe = [int(x) for x in col(8, "safe")]
fig, ax = plt.subplots(3, 1, figsize=(11, 8), sharex=True, gridspec_kw={"height_ratios": [1, 1, 2]})
ax[0].plot(t, col(8, "rpm_plant"), color="tab:blue"); ax[0].set_ylabel("fan RPM"); ax[0].grid(alpha=.3)
ax[0].set_title("Fault handling (fault bits are latched until software clears them)")
ax[1].plot(t, col(8, "temp"), color="tab:orange"); ax[1].set_ylabel("temp (C)"); ax[1].grid(alpha=.3)
names = ["external pin", "fan stall", "stale sensor", "watchdog", "over-temp"]
for i, n in enumerate(names):
    ax[2].step(t, [((f >> i) & 1) * 0.8 + i * 1.0 for f in flt], where="post", label=n)
ax[2].step(t, [x * 0.8 + 5.0 for x in safe], where="post", color="k", lw=2, label="SAFE (outputs forced)")
ax[2].set_yticks([0.4 + i for i in range(6)]); ax[2].set_yticklabels(names + ["SAFE"])
ax[2].set_xlabel("simulated time (ms)"); ax[2].grid(alpha=.3)
plt.tight_layout(); plt.savefig(f"{R}/docs/fig4_faults.png", dpi=130); plt.close()
print("plots written to docs/")

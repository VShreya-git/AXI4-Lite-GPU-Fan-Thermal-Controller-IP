#!/usr/bin/env python3
"""Bug-injection (mutation) test: apply one small RTL bug at a time and check the
testbenches FAIL.  A mutant that still passes both testbenches is a 'survivor'
(a hole in the verification)."""
import os, re, shutil, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL, TB, BUILD = f"{ROOT}/rtl", f"{ROOT}/tb", f"{ROOT}/build/mut"

MUTANTS = [
 ("pwm_core.v", "(cc < s_dcnt)", "(cc <= s_dcnt)", "compare < becomes <= (0% duty glitch)"),
 ("pwm_core.v", "wire        tick     = (psc_cnt >= s_presc);", "wire        tick     = (psc_cnt > s_presc);", "prescaler off by one"),
 ("pwm_core.v", "else if (load) begin s_dcnt <= dc; s_ph <= ph; end", "else begin s_dcnt <= dc; s_ph <= ph; end", "duty shadow register removed (live update)"),
 ("pwm_core.v", "if (cnt == last) dir <= 1'b1; else cnt <= cnt + 16'd1;", "if (cnt == last - 16'd1) dir <= 1'b1; else cnt <= cnt + 16'd1;", "center-aligned peak off by one"),
 ("pwm_core.v", "dtc <= s_dead - 8'd1; end\n                            end\n                    S_LS:", "dtc <= s_dead; end\n                            end\n                    S_LS:", "dead-time one cycle too long"),
 ("pwm_core.v", "wire [NCH-1:0] pin_d = safe ? flvl[NCH-1:0]", "wire [NCH-1:0] pin_d = safe ? ~flvl[NCH-1:0]", "safe state drives wrong level"),
 ("axi4l_slave_if.v", "BRESP  <= wr_err ? 2'b10 : 2'b00;", "BRESP  <= 2'b00;", "write errors reported as OKAY"),
 ("axi4l_slave_if.v", "assign AWREADY = ~aw_got & ~BVALID;\n    assign WREADY  = ~w_got  & ~BVALID;", "assign AWREADY = ~aw_got;\n    assign WREADY  = ~w_got;", "AW/W accepted while B response pending"),
 ("fan_regs.v", "wr_err = ~w_valid | (w_lockable & r_locked);", "wr_err = ~w_valid;", "write-lock not enforced"),
 ("fan_regs.v", "r_irqst <= (r_irqst & ~irq_clr) | irq_set;", "r_irqst <= (r_irqst & irq_clr) | irq_set;", "W1C inverted"),
 ("fan_regs.v", "s[1] ? n[15:8]  : o[15:8]", "s[0] ? n[15:8]  : o[15:8]", "byte strobe 1 wired to strobe 0"),
 ("fan_regs.v", "if (wr_addr[1:0] == 2'b00) begin", "if (1'b1) begin", "unaligned address accepted"),
 ("pi_ctrl.v", "u <= hi ? 16'hFFFF : (lo ? 16'h0000 : uraw[15:0]);", "u <= uraw[15:0];", "PI output saturation removed"),
 ("pi_ctrl.v", "wire stop = (hi && (e > 18'sd0)) || (lo && (e < 18'sd0));", "wire stop = 1'b0;", "anti-windup disabled (stop term)"),
 ("pi_ctrl.v", "if (!stop) iacc <= iclamp;", "iacc <= inew;", "integrator unbounded (no anti-windup at all)"),
 ("fan_curve.v", "level <= up ? (bl + qc) : (bl - qc);", "level <= up ? (bl - qc) : (bl + qc);", "interpolation direction swapped"),
 ("tach_capture.v", "rpm      <= (prod[31:16] != 16'd0) ? 16'hFFFF : prod[15:0];", "rpm      <= pn;", "RPM multiplier ignored"),
 ("safety_ctrl.v", "wire [4:0] nxt   = (clr ? 5'd0 : lat) | (cause & fault_en);", "wire [4:0] nxt   = lat | (cause & fault_en);", "fault clear does nothing"),
 ("safety_ctrl.v", "wire [4:0] cause = {overtemp_c, wd_c, stale_c, stall_c, pin_c};", "wire [4:0] cause = {overtemp_c, wd_c, stale_c, pin_c, stall_c};", "fault bit order swapped"),
 ("fan_core.v", "if (tach_zero && c_en && (d0[15:8] >= c_stall[7:0])) begin", "if (tach_zero && c_en && (d0[15:8] > c_stall[7:0])) begin", "stall threshold compare off by one"),
 ("cdc_bus_hs.v", "dst_data  <= hold;     // 'hold' is stable: src waits for ack", "dst_data  <= src_data;", "CDC samples live bus instead of held snapshot"),
 ("fan_core.v", "if (!t_init || tdiff > c_hyst) temp_eff <= temp_raw;", "if (!t_init || tdiff >= c_hyst) temp_eff <= temp_raw;", "hysteresis boundary off by one"),
]
MUTANTS = [m for m in MUTANTS if m[3] is not None]

def run(cmd, timeout):
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout + p.stderr
    except subprocess.TimeoutExpired:
        return 124, "TIMEOUT"

SRC = "sync_ff reset_sync cdc_bus_hs axi4l_slave_if fan_regs pwm_core tach_capture div_seq fan_curve pi_ctrl safety_ctrl fan_core fan_ctrl_top".split()

def build_and_run(d, tbname, tbfile, files, top, passmsg, timeout):
    """returns 'BADBUILD' (compile error - NEVER counted as a catch), 'PASS' or 'FAIL'"""
    top_opt = f"-s {top}" if top else ""
    rc, out = run(f"iverilog -g2005 -I {d} -o {d}/{tbname}.vvp {tbfile} {files} {top_opt}", 120)
    if rc != 0:
        return "BADBUILD", out
    rc, out = run(f"vvp {d}/{tbname}.vvp", timeout)
    return ("PASS" if passmsg in out else "FAIL"), out

def one(idx):
    f, old, new, desc = MUTANTS[idx]
    d = f"{BUILD}/m{idx:02d}"
    shutil.rmtree(d, ignore_errors=True); shutil.copytree(RTL, d)
    src = open(f"{d}/{f}").read()
    if src.count(old) != 1:
        return idx, "BADPATCH", desc, f"pattern count={src.count(old)}"
    open(f"{d}/{f}", "w").write(src.replace(old, new))
    allf = " ".join(f"{d}/{m}.v" for m in SRC)
    stages = [("pwm", f"{TB}/tb_pwm_core.v", f"{d}/pwm_core.v", None, "TB_PWM: PASS", 300),
              ("cdc", f"{TB}/tb_cdc.v", f"{d}/cdc_bus_hs.v {d}/sync_ff.v", None, "TB_CDC: PASS", 120),
              ("sys", f"{TB}/tb_system.v", allf, "tb_system", "TB_SYS: PASS", 900)]
    for name, tbf, files, top, msg, to in stages:
        st, out = build_and_run(d, name, tbf, files, top, msg, to)
        if st == "BADBUILD":
            return idx, "BADBUILD", desc, out.strip().splitlines()[0][:100] if out.strip() else ""
        if st == "FAIL":
            return idx, "KILLED", desc, "tb_" + name
    return idx, "SURVIVED", desc, ""

if __name__ == "__main__":
    os.makedirs(BUILD, exist_ok=True)
    jobs = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    with ThreadPoolExecutor(jobs) as ex:
        res = sorted(ex.map(one, range(len(MUTANTS))))
    killed = sum(1 for r in res if r[1] == "KILLED")
    bad = [r for r in res if r[1] in ("BADPATCH", "BADBUILD")]
    valid = len(res) - len(bad)
    for i, st, desc, by in res:
        print(f"mutant {i:02d} {st:9s} {desc}" + (f"  [caught by {by}]" if by else ""))
    print(f"\nBUG INJECTION: {killed}/{valid} injected bugs detected")
    sys.exit(0 if killed == valid and not bad else 1)

#!/bin/bash
# Coverage run (Verilator --coverage; also proves all testbenches pass on a 2nd simulator)
set -e
cd "$(dirname "$0")/.."
RTLF="rtl/sync_ff.v rtl/reset_sync.v rtl/cdc_bus_hs.v rtl/axi4l_slave_if.v rtl/fan_regs.v rtl/pwm_core.v rtl/tach_capture.v rtl/div_seq.v rtl/fan_curve.v rtl/pi_ctrl.v rtl/safety_ctrl.v rtl/fan_core.v rtl/fan_ctrl_top.v"
rm -rf build/cov; mkdir -p build/cov
run() {  # name tbfile top rtlfiles
  sed "s/VTOP/V$3/g" scripts/cov_main.cpp > build/cov/main_$1.cpp
  verilator --cc --exe --build --timing --coverage -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD \
     -Irtl --top-module $3 -Mdir build/cov/$1 -o sim_$1 $2 $4 $(pwd)/build/cov/main_$1.cpp > build/cov/$1.build.log 2>&1
  (cd build/cov/$1 && ./sim_$1 2>&1 | grep -E "TB_")
}
run pwm tb/tb_pwm_core.v tb_pwm_core rtl/pwm_core.v
run cdc tb/tb_cdc.v      tb_cdc      "rtl/cdc_bus_hs.v rtl/sync_ff.v"
run sys tb/tb_system.v   tb_system   "$RTLF"
python3 scripts/cov_report.py

`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// tb_system : full-chip self-checking test of fan_ctrl_top
//   - AXI4-Lite master BFM (AW/W ordering modes, delays, back-pressure)
//   - AXI protocol monitor (stability, ordering, X checks)
//   - fan plant model (PWM -> RPM with lag -> tach pulses) and temp sensor
//   - ACLK (10 ns) and PCLK (13 ns) are asynchronous
// -----------------------------------------------------------------------------
module tb_system;
    localparam NCH = 4;
    localparam SEC = 20000;            // one "second" of tach gate, in PCLK cycles

    reg ACLK = 0, PCLK = 0, RESETN = 0;
    always #5    ACLK = ~ACLK;
    always #6.5  PCLK = ~PCLK;

    reg  [7:0]  AWADDR = 0, ARADDR = 0;
    reg         AWVALID = 0, WVALID = 0, BREADY = 0, ARVALID = 0, RREADY = 0;
    reg  [31:0] WDATA = 0;
    reg  [3:0]  WSTRB = 4'hF;
    wire        AWREADY, WREADY, BVALID, ARREADY, RVALID;
    wire [1:0]  BRESP, RRESP;
    wire [31:0] RDATA;
    wire [NCH-1:0] PWM_OUT;
    wire        IRQ, PWM_SYNC_OUT;
    reg         TACH_IN = 0, TEMP_VALID = 0, FAULT_IN = 0, SYNC_IN = 0;
    reg  [7:0]  TEMP_IN = 25;

    fan_ctrl_top #(.NCH(NCH)) dut (
        .ACLK(ACLK), .PCLK(PCLK), .RESETN(RESETN),
        .AWADDR(AWADDR), .AWVALID(AWVALID), .AWREADY(AWREADY),
        .WDATA(WDATA), .WSTRB(WSTRB), .WVALID(WVALID), .WREADY(WREADY),
        .BRESP(BRESP), .BVALID(BVALID), .BREADY(BREADY),
        .ARADDR(ARADDR), .ARVALID(ARVALID), .ARREADY(ARREADY),
        .RDATA(RDATA), .RRESP(RRESP), .RVALID(RVALID), .RREADY(RREADY),
        .PWM_OUT(PWM_OUT), .PWM_SYNC_OUT(PWM_SYNC_OUT), .IRQ(IRQ),
        .TACH_IN(TACH_IN), .TEMP_IN(TEMP_IN), .TEMP_VALID(TEMP_VALID),
        .FAULT_IN(FAULT_IN), .SYNC_IN(SYNC_IN));

    // register byte addresses
    localparam R_ID=8'h00, R_CTRL=8'h04, R_STATUS=8'h08, R_IRQEN=8'h0C, R_IRQST=8'h10,
               R_LOCK=8'h14, R_PRESC=8'h18, R_PERIOD=8'h1C, R_DEAD=8'h20, R_POL=8'h24,
               R_FLVL=8'h28, R_GAMMA=8'h2C, R_DUTY0=8'h30, R_PHASE0=8'h50, R_CT=8'h70,
               R_CL0=8'h74, R_HYST=8'h84, R_TCRIT=8'h88, R_FANMIN=8'h8C, R_TEMPSW=8'h90,
               R_TEMPNOW=8'h94, R_KP=8'h98, R_KI=8'h9C, R_RPMMAX=8'hA0, R_GATE=8'hA4,
               R_MULT=8'hA8, R_STALL=8'hAC, R_FAULTEN=8'hB0, R_STALETO=8'hB4,
               R_WDOGTO=8'hB8, R_WDOGCTL=8'hBC, R_KICK=8'hC0, R_FSTAT=8'hC4,
               R_FCLR=8'hC8, R_TCLR=8'hCC, R_RPM=8'hD0, R_DUTYNOW=8'hD4, R_DMIN=8'hD8,
               R_DMAX=8'hDC, R_FCNT=8'hE0;

    integer errors = 0, checks = 0;
    task check;
        input cond; input [8*40-1:0] msg;
        begin
            checks = checks + 1;
            if (!cond) begin errors = errors + 1; $display("[%0t] CHECK FAILED: %0s", $time, msg); end
        end
    endtask

    // ---------------- AXI protocol monitor ----------------
    integer mon_err = 0, aw_n = 0, w_n = 0, b_n = 0, ar_n = 0, r_n = 0;
    reg        mon_on = 0;
    reg        bv_q = 0, rv_q = 0, br_q = 0, rr_q = 0;
    reg [1:0]  bresp_q, rresp_q; reg [31:0] rdata_q;
    always @(posedge ACLK) if (RESETN) begin
        if (^{AWREADY, WREADY, BVALID, ARREADY, RVALID, BRESP, RRESP} === 1'bx) begin mon_err = mon_err + 1; $display("MON: X on AXI outputs"); end
        if (BVALID && ^RDATA === 1'bx && RVALID) begin mon_err = mon_err + 1; $display("MON: X on RDATA"); end
        if (bv_q && !br_q && !(BVALID && BRESP === bresp_q)) begin mon_err = mon_err + 1; $display("MON: BVALID dropped/changed before BREADY"); end
        if (rv_q && !rr_q && !(RVALID && RRESP === rresp_q && RDATA === rdata_q)) begin mon_err = mon_err + 1; $display("MON: RVALID dropped/changed before RREADY"); end
        if (AWVALID && AWREADY) aw_n = aw_n + 1;
        if (WVALID && WREADY)   w_n  = w_n + 1;
        if (BVALID && BREADY)   b_n  = b_n + 1;
        if (ARVALID && ARREADY) ar_n = ar_n + 1;
        if (RVALID && RREADY)   r_n  = r_n + 1;
        if (b_n > aw_n || b_n > w_n) begin mon_err = mon_err + 1; $display("MON: B response without AW+W"); end
        if (r_n > ar_n) begin mon_err = mon_err + 1; $display("MON: R response without AR"); end
        bv_q <= BVALID; br_q <= BREADY; bresp_q <= BRESP;
        rv_q <= RVALID; rr_q <= RREADY; rresp_q <= RRESP; rdata_q <= RDATA;
    end

    // ---------------- AXI BFM ----------------
    task aw_chan; input [7:0] a; input integer dly;
        begin repeat (dly) @(posedge ACLK); #1 AWADDR = a; AWVALID = 1;
              @(posedge ACLK); while (!AWREADY) @(posedge ACLK); #1 AWVALID = 0; end endtask
    task w_chan; input [31:0] d; input [3:0] s; input integer dly;
        begin repeat (dly) @(posedge ACLK); #1 WDATA = d; WSTRB = s; WVALID = 1;
              @(posedge ACLK); while (!WREADY) @(posedge ACLK); #1 WVALID = 0; end endtask
    task b_chan; input integer dly; output [1:0] r;
        begin repeat (dly) @(posedge ACLK); #1 BREADY = 1;
              @(posedge ACLK); while (!BVALID) @(posedge ACLK); r = BRESP; #1 BREADY = 0; end endtask

    // mode 0: AW then W   1: W then AW   2: simultaneous
    task wrx; input [7:0] a; input [31:0] d; input [3:0] s; input integer mode;
              input integer dB; output [1:0] r;
        begin
            case (mode)
                0: begin aw_chan(a, 0); w_chan(d, s, 2); end
                1: begin w_chan(d, s, 0); aw_chan(a, 3); end
                default: fork aw_chan(a, 0); w_chan(d, s, 0); join
            endcase
            b_chan(dB, r);
        end endtask

    reg [1:0] resp; reg [31:0] rdv;
    task wr; input [7:0] a; input [31:0] d;
        begin wrx(a, d, 4'hF, 2, 0, resp); check(resp == 2'b00, "write OKAY"); end endtask
    task wr_err; input [7:0] a; input [31:0] d;
        begin wrx(a, d, 4'hF, 2, 0, resp); check(resp == 2'b10, "write SLVERR"); end endtask
    task rdx; input [7:0] a; input integer dR; output [31:0] d; output [1:0] r;
        begin
            @(posedge ACLK); #1 ARADDR = a; ARVALID = 1;
            @(posedge ACLK); while (!ARREADY) @(posedge ACLK); #1 ARVALID = 0;
            repeat (dR) @(posedge ACLK);
            #1 RREADY = 1; @(posedge ACLK); while (!RVALID) @(posedge ACLK);
            d = RDATA; r = RRESP; #1 RREADY = 0;
        end endtask
    task rd; input [7:0] a; begin rdx(a, 0, rdv, resp); check(resp == 2'b00, "read OKAY"); end endtask
    task rd_err; input [7:0] a; begin rdx(a, 0, rdv, resp); check(resp == 2'b10, "read SLVERR"); end endtask
    task expect_reg; input [7:0] a; input [31:0] v; input [8*40-1:0] msg;
        begin rd(a); checks = checks + 1;
              if (rdv !== v) begin errors = errors + 1; $display("[%0t] REG %0s (0x%02h): got %h exp %h", $time, msg, a, rdv, v); end end endtask
    task walk_reg; input [7:0] a; input [31:0] mask;
        reg [31:0] orig;
        begin
            rd(a); orig = rdv;
            wr(a, 32'hA5C3_5A96 & mask); expect_reg(a, 32'hA5C3_5A96 & mask, "walk pattern A");
            wr(a, 32'h5A3C_A569 & mask); expect_reg(a, 32'h5A3C_A569 & mask, "walk pattern B");
            wr(a, orig);
        end
    endtask
    task wait_p; input integer n; begin repeat (n) @(posedge PCLK); end endtask
    task wait_cfg; begin wait_p(60); end endtask

    // ---------------- fan plant + tach ----------------
    real fan_gain = 5000.0;      // rpm at 100 % duty
    real rpm_real = 0.0;
    real ph_acc   = 0.0;
    integer hi_cnt = 0, win_cnt = 0;
    reg fan_stuck = 0;
    always @(posedge PCLK) begin
        hi_cnt = hi_cnt + PWM_OUT[0];
        win_cnt = win_cnt + 1;
        if (win_cnt == 500) begin
            rpm_real = rpm_real + ((fan_stuck ? 0.0 : fan_gain * hi_cnt / 500.0) - rpm_real) * 0.5;
            if (fan_stuck) rpm_real = 0.0;
            hi_cnt = 0; win_cnt = 0;
        end
        ph_acc = ph_acc + rpm_real / 30.0 / SEC;     // pulses per cycle (2 pulses / rev)
        if (ph_acc >= 1.0) ph_acc = ph_acc - 1.0;
        TACH_IN <= (ph_acc < 0.5) && (rpm_real > 1.0);
    end

    // hardware temperature sensor strobes (when enabled)
    reg temp_strobes = 0;
    integer ts_cnt = 0;
    always @(posedge PCLK) begin
        TEMP_VALID <= 1'b0;
        if (temp_strobes) begin
            ts_cnt = ts_cnt + 1;
            if (ts_cnt == 50) begin ts_cnt = 0; TEMP_VALID <= 1'b1; end
        end
    end

    // pin duty measurement
    integer hi_m;
    task measure_duty; input integer ch; input integer ncyc; output integer hi;
        integer i;
        begin hi = 0; for (i = 0; i < ncyc; i = i + 1) begin @(posedge PCLK); hi = hi + PWM_OUT[ch]; end end endtask

    function integer iabs; input integer v; begin iabs = (v < 0) ? -v : v; end endfunction

    integer lat_ext = -1;

    integer i, hi, exp_h, tmp;
    reg [1:0] r1, r2;
    integer t_start;

    initial begin
        #100; RESETN = 0;
        repeat (6) @(posedge ACLK);
        #3 RESETN = 1;
        repeat (10) @(posedge ACLK);
        mon_on = 1;

        // ===== T1: reset values =====
        $display("[T1] reset values");
        expect_reg(R_ID,     32'h4641_4E01, "ID");
        expect_reg(R_CTRL,   32'h0, "CTRL");
        expect_reg(R_PERIOD, 32'd1000, "PERIOD");
        expect_reg(R_DUTY0,  32'h8000, "DUTY0");
        expect_reg(R_FLVL,   32'h01, "FLVL");
        expect_reg(R_STATUS, 32'h0, "STATUS");
        check(PWM_OUT === 4'b0000, "pins low after reset");

        // ===== T2: register read/write + byte strobes =====
        $display("[T2] register RW and WSTRB");
        wr(R_PERIOD, 32'h0000_1234); expect_reg(R_PERIOD, 32'h1234, "PERIOD rw");
        wrx(R_PERIOD, 32'h0000_00AB, 4'b0001, 2, 0, resp); check(resp == 0, "strb ok");
        expect_reg(R_PERIOD, 32'h12AB, "PERIOD strb0");
        wrx(R_PERIOD, 32'h0000_CD00, 4'b0010, 2, 0, resp);
        expect_reg(R_PERIOD, 32'hCDAB, "PERIOD strb1");
        wrx(R_PERIOD, 32'hFFFF_0000, 4'b1100, 2, 0, resp);
        expect_reg(R_PERIOD, 32'hCDAB, "PERIOD upper strobes ignored");
        wr(R_GATE, 32'hDEAD_BEEF); expect_reg(R_GATE, 32'hDEAD_BEEF, "GATE 32b");
        wrx(R_GATE, 32'h0000_0011, 4'b0001, 0, 0, resp); expect_reg(R_GATE, 32'hDEAD_BE11, "GATE strb0");
        wr(R_CT, 32'h4B3C_2D1E); expect_reg(R_CT, 32'h4B3C_2D1E, "CT");
        wr(R_KP, 32'h1234); expect_reg(R_KP, 32'h1234, "KP");
        wr(R_DUTY0 + 8'h0C, 32'hBEEF); expect_reg(R_DUTY0 + 8'h0C, 32'hBEEF, "DUTY3");
        wr(R_PHASE0 + 8'h04, 32'h0033); expect_reg(R_PHASE0 + 8'h04, 32'h33, "PHASE1");
        wr(R_PERIOD, 32'd100);   // restore sane

        // ===== T2b: walk every writable register (write two patterns, read back, restore) =====
        $display("[T2b] register walk");
        walk_reg(R_IRQEN, 32'h7);     walk_reg(R_PRESC, 32'hFFFF);  walk_reg(R_PERIOD, 32'hFFFF);
        walk_reg(R_DEAD, 32'hFF);     walk_reg(R_POL, 32'hFF);      walk_reg(R_FLVL, 32'hFF);
        walk_reg(R_GAMMA, 32'hFF);    walk_reg(R_CT, 32'hFFFF_FFFF);
        walk_reg(R_CL0, 32'hFFFF);    walk_reg(R_CL0 + 4, 32'hFFFF); walk_reg(R_CL0 + 8, 32'hFFFF); walk_reg(R_CL0 + 12, 32'hFFFF);
        walk_reg(R_HYST, 32'hFF);     walk_reg(R_TCRIT, 32'hFF);    walk_reg(R_FANMIN, 32'hFFFF);
        walk_reg(R_TEMPSW, 32'hFF);   walk_reg(R_KP, 32'hFFFF);     walk_reg(R_KI, 32'hFFFF);
        walk_reg(R_RPMMAX, 32'hFFFF); walk_reg(R_GATE, 32'hFFFF_FFFF); walk_reg(R_MULT, 32'hFFFF);
        walk_reg(R_STALL, 32'hFFF);   walk_reg(R_FAULTEN, 32'h1F);  walk_reg(R_STALETO, 32'hFF_FFFF);
        walk_reg(R_WDOGTO, 32'hFF_FFFF); walk_reg(R_WDOGCTL, 32'h1);
        for (i = 0; i < 4; i = i + 1) begin walk_reg(R_DUTY0 + 4*i, 32'hFFFF); walk_reg(R_PHASE0 + 4*i, 32'hFFFF); end
        // read-only / write-only registers: legal reads
        rd(R_STATUS); rd(R_FSTAT); rd(R_RPM); rd(R_DUTYNOW); rd(R_DMIN); rd(R_DMAX); rd(R_FCNT); rd(R_TEMPNOW);
        expect_reg(R_KICK, 0, "WO KICK reads 0"); expect_reg(R_FCLR, 0, "WO FCLR reads 0"); expect_reg(R_TCLR, 0, "WO TCLR reads 0");

        // ===== T3: AXI ordering / back-pressure =====
        $display("[T3] AXI channel ordering and back-pressure");
        for (i = 0; i < 3; i = i + 1) begin
            wrx(R_HYST, 32'h10 + i, 4'hF, i, i * 2, resp);
            check(resp == 0, "ordered write OKAY");
            expect_reg(R_HYST, 32'h10 + i, "HYST ordered");
        end
        rdx(R_ID, 5, rdv, resp); check(rdv === 32'h4641_4E01 && resp == 0, "read with RREADY delay");
        for (i = 0; i < 8; i = i + 1) begin wr(R_TEMPSW, i); end   // back-to-back
        expect_reg(R_TEMPSW, 7, "back-to-back last value");
        // pipelined writes: 2nd write issued before the 1st response is accepted
        fork aw_chan(8'hF0, 0); w_chan(32'h1, 4'hF, 0); join          // write 1: unmapped -> SLVERR
        fork
            begin aw_chan(R_HYST, 0); end
            begin w_chan(32'h07, 4'hF, 0); end
            begin b_chan(12, r1); b_chan(0, r2); end
        join
        check(r1 == 2'b10, "pipelined: write1 SLVERR preserved");
        check(r2 == 2'b00, "pipelined: write2 OKAY");
        expect_reg(R_HYST, 7, "pipelined write2 applied");
        wr(R_HYST, 2);

        // ===== T4: errors and lock =====
        $display("[T4] SLVERR and write lock");
        wr_err(8'hF0, 32'h1);               // unmapped
        wr_err(R_ID,  32'h1);               // read-only
        wr_err(R_RPM, 32'h1);               // read-only telemetry
        wr_err(R_DUTY0 + 8'h10, 32'h1);     // channel 4 does not exist (NCH=4)
        wr_err(R_CTRL + 8'h01, 32'h1);      // unaligned
        rd_err(8'hF4); rd_err(R_DUTY0 + 8'h10); rd_err(R_CTRL + 8'h02);
        wr(R_PERIOD, 32'd100);
        wr(R_LOCK, 32'hA5);
        expect_reg(R_LOCK, 1, "locked");
        wr_err(R_PERIOD, 32'd555);          // lockable -> SLVERR
        expect_reg(R_PERIOD, 100, "PERIOD unchanged while locked");
        wr(R_DUTY0, 32'h4000);              // non-critical still writable
        wr_err(R_LOCK, 32'h11);             // bad key
        wr(R_LOCK, 32'h5A);
        expect_reg(R_LOCK, 0, "unlocked");
        wr(R_PERIOD, 32'd100); expect_reg(R_PERIOD, 100, "PERIOD writable again");

        // ===== T5: manual PWM duty at the pin =====
        $display("[T5] manual PWM duty, 0%%/100%%, polarity");
        wr(R_PERIOD, 100); wr(R_PRESC, 0); wr(R_DUTY0, 32'h4000);   // 25 %
        wr(R_CTRL, 32'h1);
        wait_cfg; wait_p(500);
        measure_duty(0, 5000, hi); $display("      25%% duty measured: %0d / 5000", hi);
        check(iabs(hi - 1250) <= 60, "25% duty");
        wr(R_DUTY0, 32'hFFFF); wait_cfg; wait_p(300);
        measure_duty(0, 2000, hi); check(hi == 2000, "100% duty exact");
        wr(R_DUTY0, 32'h0); wait_cfg; wait_p(300);
        measure_duty(0, 2000, hi); check(hi == 0, "0% duty exact");
        wr(R_POL, 32'h01); wait_cfg; wait_p(300);
        measure_duty(0, 2000, hi); check(hi == 2000, "polarity inverts 0% -> pin high");
        wr(R_POL, 32'h00);
        // gamma: duty 0x8000 -> (0.5)^2 = 25 %
        wr(R_DUTY0 + 4, 32'h8000); wr(R_GAMMA, 32'h02); wait_cfg; wait_p(500);
        measure_duty(1, 5000, hi); $display("      gamma(50%%) measured: %0d / 5000", hi);
        check(iabs(hi - 1250) <= 60, "gamma channel 25%");
        wr(R_GAMMA, 0);
        // phase offset: ch2 and ch3 same duty, ch3 shifted by half period
        wr(R_DUTY0 + 8, 32'h4000); wr(R_DUTY0 + 12, 32'h4000); wr(R_PHASE0 + 12, 50); wait_cfg; wait_p(400);
        begin : ph_chk
            integer diff; diff = 0;
            for (i = 0; i < 1000; i = i + 1) begin @(posedge PCLK); if (PWM_OUT[2] !== PWM_OUT[3]) diff = diff + 1; end
            check(diff > 400, "phase offset separates ch2/ch3");
        end
        wr(R_PHASE0 + 12, 0);
        // complementary + dead-time end-to-end
        wr(R_DUTY0 + 0, 32'h8000); wr(R_DEAD, 4); wr(R_CTRL, 32'h11); wait_cfg; wait_p(600);
        begin : comp_chk
            integer ov, gaprun, bad, seen;
            ov = 0; gaprun = 0; bad = 0; seen = 0;
            for (i = 0; i < 3000; i = i + 1) begin
                @(posedge PCLK);
                if (PWM_OUT[0] & PWM_OUT[1]) ov = ov + 1;
                if (PWM_OUT[0] | PWM_OUT[1]) begin
                    if (seen && gaprun != 0 && gaprun != 4) bad = bad + 1;
                    gaprun = 0; seen = 1;
                end else gaprun = gaprun + 1;
            end
            check(ov == 0, "no complementary overlap");
            check(bad == 0, "dead-time == DEAD register (4)");
        end
        wr(R_CTRL, 32'h1); wr(R_DEAD, 0);
        // center-aligned still gives same average duty
        wr(R_DUTY0, 32'h4000); wr(R_CTRL, 32'h9); wait_cfg; wait_p(600);
        measure_duty(0, 4000, hi); check(iabs(hi - 1000) <= 60, "center-aligned 25%");
        wr(R_CTRL, 32'h1);

        // ===== T6: temperature curve =====
        $display("[T6] fan curve interpolation + hysteresis");
        wr(R_CT, {8'd75, 8'd60, 8'd45, 8'd30});
        wr(R_CL0, 32'h4000); wr(R_CL0+4, 32'h8000); wr(R_CL0+8, 32'hC000); wr(R_CL0+12, 32'hFFFF);
        wr(R_CTRL, 32'h2b);                 // en + mode1(curve) + temp from SW reg   (bit5)
        wr(R_TEMPSW, 52); wait_cfg; wait_p(300);
        rd(R_DUTYNOW);
        tmp = 32768 + (7 * 16384) / 15;     // 40413
        $display("      curve(52C) = %0d (expect %0d)", rdv, tmp);
        check(iabs(rdv - tmp) <= 1, "curve interpolation 52C");
        wr(R_TEMPSW, 53); wait_cfg; wait_p(300);   // inside hysteresis (2) -> unchanged
        rd(R_DUTYNOW); check(iabs(rdv - tmp) <= 1, "hysteresis holds");
        expect_reg(R_TEMPNOW, 52, "TEMPNOW held");
        wr(R_TEMPSW, 56); wait_cfg; wait_p(300);
        rd(R_DUTYNOW); tmp = 32768 + (11 * 16384) / 15;
        check(iabs(rdv - tmp) <= 1, "curve 56C after hysteresis exit");
        wr(R_TEMPSW, 58); wait_cfg; wait_p(300);   // |58-56| == HYST -> still held
        rd(R_DUTYNOW); check(iabs(rdv - tmp) <= 1, "hysteresis boundary (diff == HYST) holds");
        wr(R_TEMPSW, 20); wait_cfg; wait_p(300); rd(R_DUTYNOW); check(rdv == 32'h4000, "clamp low");
        wr(R_TEMPSW, 80); wait_cfg; wait_p(300); rd(R_DUTYNOW); check(rdv == 32'hFFFF, "clamp high");
        wr(R_TEMPSW, 38); wait_cfg; wait_p(300); rd(R_DUTYNOW);
        tmp = 16384 + (8 * 16384) / 15;     // seg0
        check(iabs(rdv - tmp) <= 1, "curve segment 0");
        wr(R_TEMPSW, 68); wait_cfg; wait_p(300); rd(R_DUTYNOW);
        tmp = 49152 + (8 * 16383) / 15;     // segment 2 (60..75 C): 57889
        $display("      curve(68C) = %0d (expect %0d)", rdv, tmp);
        check(iabs(rdv - tmp) <= 1, "curve segment 2");
        wr(R_FANMIN, 32'h5000); wr(R_TEMPSW, 20); wait_cfg; wait_p(300); rd(R_DUTYNOW);
        check(rdv == 32'h5000, "FAN_MIN clamp"); wr(R_FANMIN, 0);

        // ===== T7: closed-loop RPM control =====
        $display("[T7] closed-loop PI against fan model (gain error 20%%)");
        wr(R_CTRL, 32'h0); wait_cfg;
        fan_gain = 4000.0;                  // plant is weaker than RPM_MAX assumes
        wr(R_GATE, SEC); wr(R_MULT, 30); wr(R_RPMMAX, 5000);
        wr(R_KP, 32'h0200); wr(R_KI, 32'h0200);
        wr(R_STALL, {20'd0, 4'd0, 8'h20});  // stall detection off (windows = 0)
        wr(R_DUTY0, 32'h8000);              // target = 50 % of 5000 = 2500 rpm
        wr(R_CTRL, 32'h7);                  // en + mode 3
        wait_p(SEC * 50);
        rd(R_RPM); $display("      steady RPM = %0d (target 2500)", rdv);
        check(iabs(rdv - 2500) <= 100, "closed loop reaches target RPM");
        rd(R_DUTYNOW); $display("      duty = %0d (ideal %0d)", rdv, 40000);
        check(iabs(rdv - 40960) <= 2500, "PI compensates gain error");
        // actuator saturation: fan too weak, then recovers
        fan_gain = 1500.0; wait_p(SEC * 30);
        rd(R_DUTYNOW); check(rdv == 32'hFFFF, "PI output saturates at 100%");
        fan_gain = 4000.0; wait_p(SEC * 28);
        rd(R_RPM); $display("      RPM after windup recovery = %0d", rdv);
        check(iabs(rdv - 2500) <= 120, "anti-windup: recovers promptly");

        // ===== T8: faults =====
        $display("[T8] fault handling");
        wr(R_CTRL, 32'h21);                 // manual mode, SW temp
        wr(R_DUTY0, 32'h2000);              // 12.5 % -> top byte 0x20
        wr(R_PERIOD, 100); wr(R_TEMPSW, 25);
        wr(R_STALL, {20'd0, 4'd3, 8'h20});
        fan_gain = 5000.0; wait_p(SEC * 3);
        expect_reg(R_FSTAT, 0, "no faults while healthy");
        // --- stall
        fan_stuck = 1; wait_p(SEC * 6);
        rd(R_FSTAT); check(rdv[1] == 1, "stall fault latched");
        expect_reg(R_STATUS, 32'h1, "STATUS.safe");
        wr(R_FCLR, 0); wait_cfg; wait_p(200);        // writing 0 must NOT clear
        rd(R_FSTAT); check(rdv[1] == 1, "FCLR write of 0 does nothing");
        wrx(R_FCLR, 32'h1, 4'b0010, 2, 0, resp);     // strobe on wrong byte lane must NOT clear
        wrx(R_TCLR, 32'h1, 4'b0100, 2, 0, resp);
        wrx(R_KICK, 32'h1, 4'b0000, 2, 0, resp);
        wrx(R_WDOGCTL, 32'h1, 4'b0010, 2, 0, resp);
        wait_cfg; wait_p(200);
        rd(R_FSTAT); check(rdv[1] == 1, "FCLR with wrong byte strobe does nothing");
        expect_reg(R_WDOGCTL, 0, "WDOGCTL with wrong strobe unchanged");
        wait_p(200);
        begin : safe_pin
            integer h; measure_duty(0, 600, h); check(h == 600, "pin0 forced to FLVL=1 in safe state");
            measure_duty(1, 600, h); check(h == 0, "pin1 forced to FLVL=0 in safe state");
        end
        wr(R_FCLR, 1); wait_cfg; wait_p(200);
        rd(R_FSTAT); check(rdv[1] == 1, "clear while cause persists re-latches");
        fan_stuck = 0; wait_p(SEC * 5);
        wr(R_FCLR, 1); wait_cfg; wait_p(300);
        expect_reg(R_FSTAT, 0, "stall cleared after fan recovers");
        expect_reg(R_STATUS, 0, "safe released");
        // --- over-temperature
        wr(R_DUTY0, 0);                    // 0 % so pin0 is low until fault
        wait_cfg; wait_p(400);
        wr(R_TEMPSW, 95);
        t_start = 0;
        wait_p(1500);
        rd(R_FSTAT); check(rdv[4] == 1, "over-temp fault latched");
        begin : ot_lat
            integer h; measure_duty(0, 300, h); check(h == 300, "over-temp drives pin to 100%");
        end
        wr(R_TEMPSW, 40); wait_cfg; wait_p(500);
        wr(R_FCLR, 1); wait_cfg; wait_p(500);
        expect_reg(R_FSTAT, 0, "over-temp cleared");
        // --- fault enable mask
        wr(R_FAULTEN, 32'h0F); wr(R_TEMPSW, 95); wait_cfg; wait_p(1500);
        expect_reg(R_FSTAT, 0, "masked fault not latched");
        wr(R_TEMPSW, 40); wait_cfg; wait_p(300); wr(R_FAULTEN, 32'h1F);
        // --- external pin + latency
        wr(R_DUTY0, 0); wait_cfg; wait_p(500);
        @(posedge PCLK); #1 FAULT_IN = 1; lat_ext = 0;
        while (PWM_OUT[0] !== 1'b1 && lat_ext < 50) begin @(posedge PCLK); lat_ext = lat_ext + 1; end
        $display("      external FAULT_IN -> pin forced after %0d PCLK cycles (incl. 2-FF sync)", lat_ext);
        check(lat_ext <= 5, "external fault latency <= 5 cycles");
        wait_p(40); rd(R_FSTAT); check(rdv[0] == 1, "pin fault latched");
        FAULT_IN = 0; wait_p(50); wr(R_FCLR, 1); wait_cfg; wait_p(300);
        expect_reg(R_FSTAT, 0, "pin fault cleared");
        // --- stale sensor (hardware temperature source)
        wr(R_CTRL, 32'h01); wr(R_STALETO, 400);
        temp_strobes = 1; wait_cfg; wait_p(2000);
        expect_reg(R_FSTAT, 0, "no stale fault while strobes arrive");
        temp_strobes = 0; wait_p(1500);
        rd(R_FSTAT); check(rdv[2] == 1, "stale-sensor fault");
        temp_strobes = 1; wait_p(400); wr(R_FCLR, 1); wait_cfg; wait_p(500);
        expect_reg(R_FSTAT, 0, "stale fault cleared once strobes resume");
        temp_strobes = 0; wr(R_STALETO, 0);
        // --- watchdog
        wr(R_CTRL, 32'h21); wr(R_WDOGTO, 600); wr(R_WDOGCTL, 1); wait_cfg;
        for (i = 0; i < 30; i = i + 1) begin wr(R_KICK, 1); wait_p(300); end
        expect_reg(R_FSTAT, 0, "kicked watchdog: no fault");
        wait_p(1500);
        rd(R_FSTAT); check(rdv[3] == 1, "watchdog timeout fault");
        wr(R_WDOGCTL, 0); wait_cfg; wr(R_FCLR, 1); wait_cfg; wait_p(300);
        expect_reg(R_FSTAT, 0, "watchdog fault cleared");
        // --- telemetry
        rd(R_FCNT); $display("      fault counter = %0d", rdv); check(rdv >= 5, "fault counter counted events");
        rd(R_DMAX); check(rdv >= 0, "DMAX readable");
        wr(R_TCLR, 1); wait_cfg; wait_p(300);
        expect_reg(R_FCNT, 0, "telemetry clear resets fault counter");

        // ===== T9: interrupts =====
        $display("[T9] interrupt enable / status / W1C");
        wr(R_CTRL, 32'h20); wr(R_IRQEN, 0); wait_cfg; wait_p(800);   // PWM off: no period ticks
        wr(R_IRQST, 7); wait_cfg; wait_p(200);
        expect_reg(R_IRQST, 32'h0, "IRQST cleared");
        check(IRQ == 0, "IRQ low");
        wr(R_IRQEN, 1);
        wr(R_TEMPSW, 95); wait_cfg; wait_p(2500);
        check(IRQ == 1, "IRQ asserted on fault");
        rd(R_IRQST); check(rdv[0] == 1, "IRQST[0] set");
        wr(R_IRQST, 1); wait_cfg;
        rd(R_IRQST); check(rdv[0] == 0, "W1C clears IRQST[0]");
        check(IRQ == 0, "IRQ low after clear");
        wr(R_TEMPSW, 40); wait_cfg; wait_p(500); wr(R_FCLR, 1); wait_cfg; wait_p(500);
        wr(R_IRQEN, 32'h4); wr(R_IRQST, 7); wait_cfg;           // period-tick interrupt
        wr(R_CTRL, 32'h21); wr(R_DUTY0, 32'h8000); wait_p(2000);
        check(IRQ == 1, "period-tick IRQ");
        wr(R_IRQEN, 0); wr(R_IRQST, 7);

        // ===== T10: reset in the middle of a transaction =====
        $display("[T10] reset mid-transaction");
        fork
            begin aw_chan(R_PERIOD, 0); end
            begin #25 RESETN = 0; end
        join
        #50 RESETN = 1; AWVALID = 0; WVALID = 0; BREADY = 0;
        repeat (20) @(posedge ACLK);
        expect_reg(R_PERIOD, 1000, "reset restores PERIOD");
        expect_reg(R_CTRL, 0, "reset disables PWM");

        // ===== summary =====
        $display("");
        $display("AXI monitor: AW=%0d W=%0d B=%0d AR=%0d R=%0d  protocol errors=%0d", aw_n, w_n, b_n, ar_n, r_n, mon_err);
        errors = errors + mon_err;
        $display("TB_SYS: %0s  (checks=%0d, errors=%0d)", (errors == 0) ? "PASS" : "FAIL", checks, errors);
        $finish;
    end

    initial begin #400_000_000; $display("TB_SYS: FAIL (timeout)"); $finish; end
endmodule

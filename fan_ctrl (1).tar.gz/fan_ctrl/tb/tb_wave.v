`timescale 1ns/1ps
// Dumps per-cycle PWM pin values for three configurations to build/wave.csv (for plotting)
module tb_wave;
    reg clk = 0; always #5 clk = ~clk;
    reg rstn = 0, en = 0, center = 0, comp_en = 0;
    reg [15:0] period = 40; reg [7:0] dead = 0;
    reg [127:0] duty_f = 0, phase_f = 0;
    wire [3:0] pwm; wire fs;
    pwm_core #(.NCH(4)) dut (.clk(clk), .rstn(rstn), .en(en), .center(center), .comp_en(comp_en),
        .prescale(16'd0), .period(period), .dead(dead), .pol(8'd0), .flvl(8'd0), .gamma_en(8'd0),
        .duty_f(duty_f), .phase_f(phase_f), .safe(1'b0), .sync_in(1'b0), .sync_en(1'b0), .pwm(pwm), .frame_start(fs));
    integer f, c, scen;
    initial begin
        f = $fopen("build/wave.csv", "w");
        $fdisplay(f, "scen,cycle,p0,p1,p2,p3,frame");
        #22 rstn = 1;
        for (scen = 0; scen < 3; scen = scen + 1) begin
            @(negedge clk); en = 0; center = (scen == 1); comp_en = (scen == 2); dead = 4; period = 40;
            duty_f = {16'h4000, 16'hC000, 16'h8000, 16'h4000};      // ch0 25%, ch1 50%, ch2 75%, ch3 25%
            phase_f = {16'd20, 16'd0, 16'd10, 16'd0};               // ch3 shifted by half a period (edge mode)
            if (scen == 2) duty_f = {16'h4000, 16'h8000, 16'h8000, 16'h4000};
            repeat (3) @(negedge clk); en = 1; repeat (5) @(negedge clk);
            for (c = 0; c < 200; c = c + 1) begin
                @(negedge clk); $fdisplay(f, "%0d,%0d,%b,%b,%b,%b,%b", scen, c, pwm[0], pwm[1], pwm[2], pwm[3], fs);
            end
        end
        $fclose(f); $finish;
    end
endmodule

// AXI4-Lite slave protocol engine.
//  * AW and W are accepted independently, in any order or simultaneously.
//  * One outstanding write and one outstanding read (reads and writes are
//    independent of each other).
//  * The register file decodes combinationally: it sees wr_en/rd_en for one
//    cycle and returns wr_err / rd_data / rd_err in that same cycle.
module axi4l_slave #(
    parameter AW = 9
) (
    input  wire          ACLK,
    input  wire          ARESETN,        // already synchronised, active low

    input  wire [AW-1:0] AWADDR,
    input  wire          AWVALID,
    output wire          AWREADY,
    input  wire [31:0]   WDATA,
    input  wire [3:0]    WSTRB,
    input  wire          WVALID,
    output wire          WREADY,
    output reg  [1:0]    BRESP,
    output reg           BVALID,
    input  wire          BREADY,
    input  wire [AW-1:0] ARADDR,
    input  wire          ARVALID,
    output wire          ARREADY,
    output reg  [31:0]   RDATA,
    output reg  [1:0]    RRESP,
    output reg           RVALID,
    input  wire          RREADY,

    // register-file side
    output wire          wr_en,
    output wire [AW-1:0] wr_addr,
    output wire [31:0]   wr_data,
    output wire [3:0]    wr_strb,
    input  wire          wr_err,
    output wire          rd_en,
    output wire [AW-1:0] rd_addr,
    input  wire [31:0]   rd_data,
    input  wire          rd_err
);
    localparam [1:0] OKAY = 2'b00, SLVERR = 2'b10;

    // ---------------- write path ----------------
    reg          aw_got, w_got;
    reg [AW-1:0] aw_q;
    reg [31:0]   wd_q;
    reg [3:0]    ws_q;

    assign AWREADY = !aw_got && !BVALID;
    assign WREADY  = !w_got  && !BVALID;

    assign wr_en   = aw_got && w_got && !BVALID;
    assign wr_addr = aw_q;
    assign wr_data = wd_q;
    assign wr_strb = ws_q;

    always @(posedge ACLK) begin
        if (!ARESETN) begin
            aw_got <= 1'b0;
            w_got  <= 1'b0;
            aw_q   <= {AW{1'b0}};
            wd_q   <= 32'd0;
            ws_q   <= 4'd0;
            BVALID <= 1'b0;
            BRESP  <= OKAY;
        end else begin
            if (AWVALID && AWREADY) begin
                aw_got <= 1'b1;
                aw_q   <= AWADDR;
            end
            if (WVALID && WREADY) begin
                w_got <= 1'b1;
                wd_q  <= WDATA;
                ws_q  <= WSTRB;
            end
            if (wr_en) begin
                aw_got <= 1'b0;
                w_got  <= 1'b0;
                BVALID <= 1'b1;
                BRESP  <= wr_err ? SLVERR : OKAY;
            end else if (BVALID && BREADY) begin
                BVALID <= 1'b0;
            end
        end
    end

    // ---------------- read path ----------------
    assign ARREADY = !RVALID;
    assign rd_en   = ARVALID && ARREADY;
    assign rd_addr = ARADDR;

    always @(posedge ACLK) begin
        if (!ARESETN) begin
            RVALID <= 1'b0;
            RDATA  <= 32'd0;
            RRESP  <= OKAY;
        end else begin
            if (rd_en) begin
                RVALID <= 1'b1;
                RDATA  <= rd_err ? 32'd0 : rd_data;
                RRESP  <= rd_err ? SLVERR : OKAY;
            end else if (RVALID && RREADY) begin
                RVALID <= 1'b0;
            end
        end
    end
endmodule

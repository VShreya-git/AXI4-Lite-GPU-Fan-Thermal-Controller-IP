// -----------------------------------------------------------------------------
// axi4l_slave_if : AXI4-Lite slave -> simple register bus bridge.
//
//   * AW and W are accepted INDEPENDENTLY (any order, or simultaneously).
//   * One outstanding write and one outstanding read at a time.
//   * Write executes in the cycle after both AW and W have been captured:
//        wr_en (1-cycle pulse) with wr_addr / wr_data / wr_strb; the register
//        file answers COMBINATIONALLY in that same cycle with wr_err.
//   * Read executes in the cycle after AR is captured: rd_en pulse, rd_data /
//        rd_err valid combinationally.
//   * wr_err / rd_err -> SLVERR (2'b10), otherwise OKAY (2'b00).
//   * All outputs are registered or derived from registers (no comb. path from
//     master VALID to slave READY).
// -----------------------------------------------------------------------------
module axi4l_slave_if #(
    parameter AW = 8
) (
    input  wire          ACLK,
    input  wire          ARESETN,

    input  wire [AW-1:0] AWADDR,
    input  wire          AWVALID,
    output wire          AWREADY,
    input  wire [31:0]   WDATA,
    input  wire [3:0]    WSTRB,
    input  wire          WVALID,
    output wire          WREADY,
    output reg  [1:0]    BRESP,
    output reg           BVALID,
    input  wire          BREADY,

    input  wire [AW-1:0] ARADDR,
    input  wire          ARVALID,
    output wire          ARREADY,
    output reg  [31:0]   RDATA,
    output reg  [1:0]    RRESP,
    output reg           RVALID,
    input  wire          RREADY,

    // register bus
    output wire          wr_en,
    output wire [AW-1:0] wr_addr,
    output wire [31:0]   wr_data,
    output wire [3:0]    wr_strb,
    input  wire          wr_err,
    output wire          rd_en,
    output wire [AW-1:0] rd_addr,
    input  wire [31:0]   rd_data,
    input  wire          rd_err
);
    // ------------------------------ write ------------------------------
    reg          aw_got, w_got;
    reg [AW-1:0] awaddr_q;
    reg [31:0]   wdata_q;
    reg [3:0]    wstrb_q;

    assign AWREADY = ~aw_got & ~BVALID;
    assign WREADY  = ~w_got  & ~BVALID;

    wire aw_fire = AWVALID & AWREADY;
    wire w_fire  = WVALID  & WREADY;

    assign wr_en   = aw_got & w_got;      // exactly one cycle (flags cleared below)
    assign wr_addr = awaddr_q;
    assign wr_data = wdata_q;
    assign wr_strb = wstrb_q;

    always @(posedge ACLK or negedge ARESETN) begin
        if (!ARESETN) begin
            aw_got   <= 1'b0;
            w_got    <= 1'b0;
            awaddr_q <= {AW{1'b0}};
            wdata_q  <= 32'd0;
            wstrb_q  <= 4'd0;
            BVALID   <= 1'b0;
            BRESP    <= 2'b00;
        end else begin
            if (aw_fire) begin aw_got <= 1'b1; awaddr_q <= AWADDR; end
            if (w_fire)  begin w_got  <= 1'b1; wdata_q  <= WDATA; wstrb_q <= WSTRB; end

            if (wr_en) begin
                aw_got <= 1'b0;
                w_got  <= 1'b0;
                BVALID <= 1'b1;
                BRESP  <= wr_err ? 2'b10 : 2'b00;
            end else if (BVALID && BREADY) begin
                BVALID <= 1'b0;
            end
        end
    end

    // ------------------------------ read -------------------------------
    reg          ar_got;
    reg [AW-1:0] araddr_q;

    assign ARREADY = ~ar_got & ~RVALID;
    wire   ar_fire = ARVALID & ARREADY;

    assign rd_en   = ar_got;
    assign rd_addr = araddr_q;

    always @(posedge ACLK or negedge ARESETN) begin
        if (!ARESETN) begin
            ar_got   <= 1'b0;
            araddr_q <= {AW{1'b0}};
            RVALID   <= 1'b0;
            RRESP    <= 2'b00;
            RDATA    <= 32'd0;
        end else begin
            if (ar_fire) begin ar_got <= 1'b1; araddr_q <= ARADDR; end

            if (rd_en) begin
                ar_got <= 1'b0;
                RVALID <= 1'b1;
                RDATA  <= rd_err ? 32'd0 : rd_data;
                RRESP  <= rd_err ? 2'b10 : 2'b00;
            end else if (RVALID && RREADY) begin
                RVALID <= 1'b0;
            end
        end
    end
endmodule

// -----------------------------------------------------------------------------
// cdc_bus_hs : multi-bit clock-domain crossing using a 4-phase-equivalent
//              toggle handshake. The bus is COHERENT: all W bits arrive in the
//              destination domain together from one snapshot.
//
//   src domain : whenever src_data differs from the last snapshot and the
//                channel is idle, snapshot it into 'hold' and toggle req_t.
//   dst domain : req_t is synchronized (2-FF); on a change the (stable) 'hold'
//                is sampled into dst_data and ack_t is toggled back.
//   src domain : ack_t synchronized back; when ack == req the channel is idle.
//
//   'hold' never changes while a transfer is in flight, so the destination
//   samples a stable bus. Latency ~ 2 dst clocks + 2 src clocks + 2.
//   Assumption: both domains share ONE asynchronous reset source (each reset
//   deasserted synchronously by its own reset_sync), so req/ack start equal.
// -----------------------------------------------------------------------------
module cdc_bus_hs #(
    parameter W = 8
) (
    input  wire         src_clk,
    input  wire         src_rstn,
    input  wire [W-1:0] src_data,

    input  wire         dst_clk,
    input  wire         dst_rstn,
    output reg  [W-1:0] dst_data,
    output reg          dst_valid     // 1-cycle pulse when dst_data refreshed
);
    // ---------------- source side ----------------
    reg  [W-1:0] hold;
    reg          req_t;
    reg          busy;
    wire         ack_s;                // ack toggle, synchronized to src_clk

    always @(posedge src_clk or negedge src_rstn) begin
        if (!src_rstn) begin
            hold  <= {W{1'b0}};
            req_t <= 1'b0;
            busy  <= 1'b0;
        end else begin
            if (!busy) begin
                if (src_data != hold) begin
                    hold  <= src_data;
                    req_t <= ~req_t;
                    busy  <= 1'b1;
                end
            end else if (ack_s == req_t) begin
                busy <= 1'b0;
            end
        end
    end

    // ---------------- destination side ----------------
    wire req_s;                        // req toggle, synchronized to dst_clk
    reg  ack_t;

    sync_ff #(.STAGES(2)) u_req_sync (.clk(dst_clk), .rstn(dst_rstn), .d(req_t), .q(req_s));
    sync_ff #(.STAGES(2)) u_ack_sync (.clk(src_clk), .rstn(src_rstn), .d(ack_t), .q(ack_s));

    always @(posedge dst_clk or negedge dst_rstn) begin
        if (!dst_rstn) begin
            dst_data  <= {W{1'b0}};
            dst_valid <= 1'b0;
            ack_t     <= 1'b0;
        end else begin
            dst_valid <= 1'b0;
            if (req_s != ack_t) begin
                dst_data  <= hold;     // 'hold' is stable: src waits for ack
                dst_valid <= 1'b1;
                ack_t     <= req_s;
            end
        end
    end
endmodule

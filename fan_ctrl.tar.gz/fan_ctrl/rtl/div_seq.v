// -----------------------------------------------------------------------------
// div_seq : restoring sequential divider, NW cycles.  Caller guarantees den!=0.
// -----------------------------------------------------------------------------
module div_seq #(
    parameter NW = 24,
    parameter DW = 8
) (
    input  wire          clk,
    input  wire          rstn,
    input  wire          start,
    input  wire [NW-1:0] num,
    input  wire [DW-1:0] den,
    output reg           busy,
    output reg           done,
    output reg  [NW-1:0] q
);
    reg [NW-1:0] nsh;
    reg [DW-1:0] d, rem;
    reg [5:0]    cntr;
    wire [DW:0]  rs = {rem, nsh[NW-1]};
    wire         ge = (rs >= {1'b0, d});

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            nsh <= {NW{1'b0}}; d <= {DW{1'b0}}; rem <= {DW{1'b0}};
            cntr <= 6'd0; busy <= 1'b0; done <= 1'b0; q <= {NW{1'b0}};
        end else begin
            done <= 1'b0;
            if (start && !busy) begin
                nsh <= num; d <= den; rem <= {DW{1'b0}}; q <= {NW{1'b0}};
                cntr <= NW[5:0]; busy <= 1'b1;
            end else if (busy) begin
                nsh  <= {nsh[NW-2:0], 1'b0};
                q    <= {q[NW-2:0], ge};
                rem  <= ge ? (rs[DW-1:0] - d) : rs[DW-1:0];
                cntr <= cntr - 6'd1;
                if (cntr == 6'd1) begin busy <= 1'b0; done <= 1'b1; end
            end
        end
    end
endmodule

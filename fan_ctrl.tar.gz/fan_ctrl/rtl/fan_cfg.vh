// -----------------------------------------------------------------------------
// fan_cfg.vh : SINGLE SOURCE OF TRUTH for the ACLK->PCLK configuration bundle.
// Included inside both fan_regs (packs) and fan_core (unpacks), so the two
// sides cannot disagree on field positions.  CW_x = width, CO_x = LSB offset.
// Per-channel fields are always sized for the maximum of 8 channels.
// -----------------------------------------------------------------------------
/* verilator lint_off UNUSEDPARAM */
localparam CW_CTRL   = 8;    // [0]en [2:1]mode [3]center [4]comp [5]temp_src_sw [6]sync_en
localparam CW_PRESC  = 16;
localparam CW_PERIOD = 16;
localparam CW_DEAD   = 8;
localparam CW_POL    = 8;
localparam CW_FLVL   = 8;
localparam CW_GAMMA  = 8;
localparam CW_DUTY   = 128;  // 8 x 16
localparam CW_PHASE  = 128;  // 8 x 16
localparam CW_CT     = 32;   // 4 x 8   curve temperatures
localparam CW_CL     = 64;   // 4 x 16  curve levels
localparam CW_HYST   = 8;
localparam CW_TCRIT  = 8;
localparam CW_FANMIN = 16;
localparam CW_TEMPSW = 8;
localparam CW_KP     = 16;
localparam CW_KI     = 16;
localparam CW_RPMMAX = 16;
localparam CW_GATE   = 32;
localparam CW_MULT   = 16;
localparam CW_STALL  = 12;   // [7:0] duty threshold (top byte), [11:8] windows
localparam CW_FAULTEN= 8;
localparam CW_STALETO= 24;
localparam CW_WDOGTO = 24;
localparam CW_WDOGEN = 1;
localparam CW_CMD    = 12;   // [3:0] fault_clr_cnt [7:4] wdog_kick_cnt [11:8] tele_clr_cnt

localparam CO_CTRL   = 0;
localparam CO_PRESC  = CO_CTRL   + CW_CTRL;
localparam CO_PERIOD = CO_PRESC  + CW_PRESC;
localparam CO_DEAD   = CO_PERIOD + CW_PERIOD;
localparam CO_POL    = CO_DEAD   + CW_DEAD;
localparam CO_FLVL   = CO_POL    + CW_POL;
localparam CO_GAMMA  = CO_FLVL   + CW_FLVL;
localparam CO_DUTY   = CO_GAMMA  + CW_GAMMA;
localparam CO_PHASE  = CO_DUTY   + CW_DUTY;
localparam CO_CT     = CO_PHASE  + CW_PHASE;
localparam CO_CL     = CO_CT     + CW_CT;
localparam CO_HYST   = CO_CL     + CW_CL;
localparam CO_TCRIT  = CO_HYST   + CW_HYST;
localparam CO_FANMIN = CO_TCRIT  + CW_TCRIT;
localparam CO_TEMPSW = CO_FANMIN + CW_FANMIN;
localparam CO_KP     = CO_TEMPSW + CW_TEMPSW;
localparam CO_KI     = CO_KP     + CW_KP;
localparam CO_RPMMAX = CO_KI     + CW_KI;
localparam CO_GATE   = CO_RPMMAX + CW_RPMMAX;
localparam CO_MULT   = CO_GATE   + CW_GATE;
localparam CO_STALL  = CO_MULT   + CW_MULT;
localparam CO_FAULTEN= CO_STALL  + CW_STALL;
localparam CO_STALETO= CO_FAULTEN+ CW_FAULTEN;
localparam CO_WDOGTO = CO_STALETO+ CW_STALETO;
localparam CO_WDOGEN = CO_WDOGTO + CW_WDOGTO;
localparam CO_CMD    = CO_WDOGEN + CW_WDOGEN;
localparam CFG_W     = CO_CMD    + CW_CMD;
/* verilator lint_on UNUSEDPARAM */

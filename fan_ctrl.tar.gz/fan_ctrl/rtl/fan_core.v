// -----------------------------------------------------------------------------
// fan_core : everything in the PCLK domain - sensor conditioning, fan curve,
//            PI loop, tach, safety, PWM.  Config arrives as one coherent bundle.
//   mode 0 MANUAL      ch0 duty = DUTY0
//   mode 1 CURVE       ch0 duty = curve(temp)               (open loop)
//   mode 2 CLOSED_LOOP target RPM = curve(temp) * RPM_MAX   (PI on tach)
//   mode 3 CL_MANUAL   target RPM = DUTY0 * RPM_MAX         (PI on tach)
//   Channels 1..NCH-1 are always manual (DUTY[n]).
// -----------------------------------------------------------------------------
`include "fan_defs.vh"
module fan_core #(
    parameter NCH = 4
) (
    input  wire                    clk,
    input  wire                    rstn,
    input  wire [`FAN_CFG_W-1:0]   cfg,
    input  wire                    tach_in,
    input  wire [7:0]              temp_in,
    input  wire                    temp_valid,
    input  wire                    fault_in,
    input  wire                    sync_in,
    output wire [NCH-1:0]          pwm,
    output wire                    sync_out,
    output wire [`FAN_ST_W-1:0]    st_bus
);
    `include "fan_cfg.vh"
    `include "fan_stat.vh"

    generate if (CFG_W != `FAN_CFG_W || ST_W != `FAN_ST_W) begin : g_width_check
        BUNDLE_WIDTH_MISMATCH_update_fan_defs_vh bad();
    end endgenerate

    // ---------------- unpack ----------------
    wire [7:0]  c_ctrl    = cfg[CO_CTRL   +: CW_CTRL];
    wire [15:0] c_presc   = cfg[CO_PRESC  +: CW_PRESC];
    wire [15:0] c_period  = cfg[CO_PERIOD +: CW_PERIOD];
    wire [7:0]  c_dead    = cfg[CO_DEAD   +: CW_DEAD];
    wire [7:0]  c_pol     = cfg[CO_POL    +: CW_POL];
    wire [7:0]  c_flvl    = cfg[CO_FLVL   +: CW_FLVL];
    wire [7:0]  c_gamma   = cfg[CO_GAMMA  +: CW_GAMMA];
    wire [127:0] c_duty   = cfg[CO_DUTY   +: CW_DUTY];
    wire [127:0] c_phase  = cfg[CO_PHASE  +: CW_PHASE];
    wire [31:0] c_ct      = cfg[CO_CT     +: CW_CT];
    wire [63:0] c_cl      = cfg[CO_CL     +: CW_CL];
    wire [7:0]  c_hyst    = cfg[CO_HYST   +: CW_HYST];
    wire [7:0]  c_tcrit   = cfg[CO_TCRIT  +: CW_TCRIT];
    wire [15:0] c_fanmin  = cfg[CO_FANMIN +: CW_FANMIN];
    wire [7:0]  c_tempsw  = cfg[CO_TEMPSW +: CW_TEMPSW];
    wire [15:0] c_kp      = cfg[CO_KP     +: CW_KP];
    wire [15:0] c_ki      = cfg[CO_KI     +: CW_KI];
    wire [15:0] c_rpmmax  = cfg[CO_RPMMAX +: CW_RPMMAX];
    wire [31:0] c_gate    = cfg[CO_GATE   +: CW_GATE];
    wire [15:0] c_mult    = cfg[CO_MULT   +: CW_MULT];
    wire [11:0] c_stall   = cfg[CO_STALL  +: CW_STALL];
    wire [4:0]  c_faulten = cfg[CO_FAULTEN+: 5];
    wire [23:0] c_staleto = cfg[CO_STALETO+: CW_STALETO];
    wire [23:0] c_wdogto  = cfg[CO_WDOGTO +: CW_WDOGTO];
    wire        c_wdogen  = cfg[CO_WDOGEN];
    wire [11:0] c_cmd     = cfg[CO_CMD    +: CW_CMD];

    wire       c_en     = c_ctrl[0];
    wire [1:0] c_mode   = c_ctrl[2:1];
    wire       c_center = c_ctrl[3];
    wire       c_comp   = c_ctrl[4];
    wire       c_tsrc   = c_ctrl[5];     // 1 = software temperature register
    wire       c_syncen = c_ctrl[6];

    // ---------------- command events (counter-change detection) ----------------
    reg [11:0] cmd_q;
    always @(posedge clk or negedge rstn) begin
        if (!rstn) cmd_q <= 12'd0; else cmd_q <= c_cmd;
    end
    wire ev_fclr = (c_cmd[3:0]  != cmd_q[3:0]);
    wire ev_kick = (c_cmd[7:4]  != cmd_q[7:4]);
    wire ev_tclr = (c_cmd[11:8] != cmd_q[11:8]);

    // ---------------- async inputs ----------------
    wire fault_s, sync_s;
    sync_ff #(.STAGES(2)) u_fs (.clk(clk), .rstn(rstn), .d(fault_in), .q(fault_s));
    sync_ff #(.STAGES(2)) u_ss (.clk(clk), .rstn(rstn), .d(sync_in),  .q(sync_s));

    // ---------------- temperature conditioning (deadband hysteresis) ----------------
    reg [7:0] temp_raw, temp_eff;
    reg       t_init;
    wire [7:0] tdiff = (temp_raw > temp_eff) ? (temp_raw - temp_eff) : (temp_eff - temp_raw);
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            temp_raw <= 8'd0; temp_eff <= 8'd0; t_init <= 1'b0;
        end else begin
            if (c_tsrc)          temp_raw <= c_tempsw;
            else if (temp_valid) temp_raw <= temp_in;
            if (c_tsrc || temp_valid) t_init <= 1'b1;
            if (!t_init || tdiff > c_hyst) temp_eff <= temp_raw;
        end
    end

    // ---------------- curve ----------------
    wire [15:0] curve_lvl;
    fan_curve u_curve (.clk(clk), .rstn(rstn), .temp(temp_eff), .ct(c_ct), .cl(c_cl),
                       .level(curve_lvl));

    // ---------------- tach ----------------
    wire [15:0] rpm;
    wire        tach_valid, tach_zero;
    wire [7:0]  tach_wcnt;
    tach_capture u_tach (.clk(clk), .rstn(rstn), .tach_in(tach_in), .gate(c_gate),
        .mult(c_mult), .rpm(rpm), .valid(tach_valid), .zero_win(tach_zero), .win_cnt(tach_wcnt));

    // ---------------- target + PI ----------------
    wire [15:0] duty0_reg  = c_duty[15:0];
    wire [15:0] tgt_lvl    = (c_mode == 2'd3) ? duty0_reg : curve_lvl;
    wire [31:0] tgt_prod   = tgt_lvl * c_rpmmax;
    wire [15:0] tgt_rpm    = (tgt_lvl == 16'hFFFF) ? c_rpmmax : tgt_prod[31:16];
    wire        safe;
    wire        pi_en      = c_en & c_mode[1] & ~safe;
    wire [15:0] pi_u;
    pi_ctrl u_pi (.clk(clk), .rstn(rstn), .en(pi_en), .update(tach_valid), .target(tgt_rpm),
                  .meas(rpm), .kp(c_kp), .ki(c_ki), .preload(tgt_lvl), .u(pi_u));

    wire [15:0] auto_d = (c_mode == 2'd1) ? curve_lvl : pi_u;
    wire [15:0] d0     = (c_mode == 2'd0) ? duty0_reg : ((auto_d < c_fanmin) ? c_fanmin : auto_d);

    // ---------------- stall + over-temp detection ----------------
    reg [3:0] bad_win;
    always @(posedge clk or negedge rstn) begin
        if (!rstn) bad_win <= 4'd0;
        else if (tach_valid) begin
            if (tach_zero && c_en && (d0[15:8] >= c_stall[7:0])) begin
                if (bad_win != 4'hF) bad_win <= bad_win + 4'd1;
            end else bad_win <= 4'd0;
        end
    end
    wire stall_c    = (c_stall[11:8] != 4'd0) && (bad_win >= c_stall[11:8]);
    wire overtemp_c = (c_tcrit != 8'd0) && (temp_eff >= c_tcrit);

    // ---------------- safety ----------------
    wire [4:0] flt;
    wire [7:0] fcnt;
    safety_ctrl u_safe (.clk(clk), .rstn(rstn), .pin_c(fault_s), .stall_c(stall_c),
        .overtemp_c(overtemp_c), .hw_temp(~c_tsrc), .temp_valid(temp_valid),
        .stale_to(c_staleto), .wdog_en(c_wdogen), .wdog_to(c_wdogto), .kick(ev_kick),
        .fault_en(c_faulten), .clr(ev_fclr), .tele_clr(ev_tclr),
        .lat(flt), .safe(safe), .fcnt(fcnt));

    // ---------------- PWM ----------------
    wire fs;
    pwm_core #(.NCH(NCH)) u_pwm (.clk(clk), .rstn(rstn), .en(c_en), .center(c_center),
        .comp_en(c_comp), .prescale(c_presc), .period(c_period), .dead(c_dead),
        .pol(c_pol), .flvl(c_flvl), .gamma_en(c_gamma),
        .duty_f({c_duty[127:16], d0}), .phase_f(c_phase), .safe(safe),
        .sync_in(sync_s), .sync_en(c_syncen), .pwm(pwm), .frame_start(fs));
    assign sync_out = fs;

    // ---------------- telemetry ----------------
    reg [15:0] dmin, dmax;
    reg [7:0]  pcnt;
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            dmin <= 16'hFFFF; dmax <= 16'd0; pcnt <= 8'd0;
        end else begin
            if (fs) pcnt <= pcnt + 8'd1;
            if (ev_tclr) begin dmin <= 16'hFFFF; dmax <= 16'd0; end
            else if (c_en) begin
                if (d0 < dmin) dmin <= d0;
                if (d0 > dmax) dmax <= d0;
            end
        end
    end

    assign st_bus[SO_RPM  +: SW_RPM ] = rpm;
    assign st_bus[SO_DUTY +: SW_DUTY] = d0;
    assign st_bus[SO_TEMP +: SW_TEMP] = temp_eff;
    assign st_bus[SO_FLT  +: SW_FLT ] = {3'b000, flt};
    assign st_bus[SO_FCNT +: SW_FCNT] = fcnt;
    assign st_bus[SO_DMIN +: SW_DMIN] = dmin;
    assign st_bus[SO_DMAX +: SW_DMAX] = dmax;
    assign st_bus[SO_TCNT +: SW_TCNT] = tach_wcnt;
    assign st_bus[SO_PCNT +: SW_PCNT] = pcnt;
    assign st_bus[SO_SAFE]            = safe;
endmodule

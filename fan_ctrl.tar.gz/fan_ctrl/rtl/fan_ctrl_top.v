// -----------------------------------------------------------------------------
// fan_ctrl_top : AXI4-Lite GPU fan / thermal controller IP.
//   ACLK domain : AXI slave + register file + IRQ.
//   PCLK domain : PWM, tach, curve, PI, safety.   (ACLK, PCLK asynchronous)
//   One async reset (RESETN) -> per-domain async-assert / sync-deassert.
// -----------------------------------------------------------------------------
`include "fan_defs.vh"
module fan_ctrl_top #(
    parameter NCH = 4
) (
    input  wire              ACLK,
    input  wire              PCLK,
    input  wire              RESETN,

    input  wire [7:0]        AWADDR,
    input  wire              AWVALID,
    output wire              AWREADY,
    input  wire [31:0]       WDATA,
    input  wire [3:0]        WSTRB,
    input  wire              WVALID,
    output wire              WREADY,
    output wire [1:0]        BRESP,
    output wire              BVALID,
    input  wire              BREADY,
    input  wire [7:0]        ARADDR,
    input  wire              ARVALID,
    output wire              ARREADY,
    output wire [31:0]       RDATA,
    output wire [1:0]        RRESP,
    output wire              RVALID,
    input  wire              RREADY,

    output wire [NCH-1:0]    PWM_OUT,
    output wire              PWM_SYNC_OUT,   // frame-start pulse (ADC trigger)
    output wire              IRQ,
    input  wire              TACH_IN,
    input  wire [7:0]        TEMP_IN,        // synchronous to PCLK
    input  wire              TEMP_VALID,     // 1-cycle strobe, synchronous to PCLK
    input  wire              FAULT_IN,       // async external brake / fault
    input  wire              SYNC_IN         // async external sync
);
    wire arstn, prstn;
    reset_sync u_ars (.clk(ACLK), .arstn(RESETN), .srstn(arstn));
    reset_sync u_prs (.clk(PCLK), .arstn(RESETN), .srstn(prstn));

    wire        wr_en, rd_en, wr_err, rd_err;
    wire [7:0]  wr_addr, rd_addr;
    wire [31:0] wr_data, rd_data;
    wire [3:0]  wr_strb;

    axi4l_slave_if #(.AW(8)) u_axi (
        .ACLK(ACLK), .ARESETN(arstn),
        .AWADDR(AWADDR), .AWVALID(AWVALID), .AWREADY(AWREADY),
        .WDATA(WDATA), .WSTRB(WSTRB), .WVALID(WVALID), .WREADY(WREADY),
        .BRESP(BRESP), .BVALID(BVALID), .BREADY(BREADY),
        .ARADDR(ARADDR), .ARVALID(ARVALID), .ARREADY(ARREADY),
        .RDATA(RDATA), .RRESP(RRESP), .RVALID(RVALID), .RREADY(RREADY),
        .wr_en(wr_en), .wr_addr(wr_addr), .wr_data(wr_data), .wr_strb(wr_strb),
        .wr_err(wr_err), .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd_data), .rd_err(rd_err));

    wire [`FAN_CFG_W-1:0] cfg_a, cfg_p;
    wire [`FAN_ST_W-1:0]  st_p,  st_a;

    fan_regs #(.NCH(NCH)) u_regs (
        .ACLK(ACLK), .ARESETN(arstn),
        .wr_en(wr_en), .wr_addr(wr_addr), .wr_data(wr_data), .wr_strb(wr_strb), .wr_err(wr_err),
        .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd_data), .rd_err(rd_err),
        .cfg_bus(cfg_a), .st_bus(st_a), .irq(IRQ));

    cdc_bus_hs #(.W(`FAN_CFG_W)) u_cfg_cdc (
        .src_clk(ACLK), .src_rstn(arstn), .src_data(cfg_a),
        .dst_clk(PCLK), .dst_rstn(prstn), .dst_data(cfg_p), .dst_valid());

    cdc_bus_hs #(.W(`FAN_ST_W)) u_st_cdc (
        .src_clk(PCLK), .src_rstn(prstn), .src_data(st_p),
        .dst_clk(ACLK), .dst_rstn(arstn), .dst_data(st_a), .dst_valid());

    fan_core #(.NCH(NCH)) u_core (
        .clk(PCLK), .rstn(prstn), .cfg(cfg_p),
        .tach_in(TACH_IN), .temp_in(TEMP_IN), .temp_valid(TEMP_VALID),
        .fault_in(FAULT_IN), .sync_in(SYNC_IN),
        .pwm(PWM_OUT), .sync_out(PWM_SYNC_OUT), .st_bus(st_p));
endmodule

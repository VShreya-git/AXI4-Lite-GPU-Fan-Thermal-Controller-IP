// -----------------------------------------------------------------------------
// fan_curve : 4-point temperature -> level piecewise-linear table.
//   level = l_i + (t - t_i) * (l_{i+1} - l_i) / (t_{i+1} - t_i)   (sequential
//   divider).  Clamped to l0 below t0 and to l3 above t3.  Re-evaluates
//   continuously (~30 cycles per evaluation).
// -----------------------------------------------------------------------------
module fan_curve (
    input  wire        clk,
    input  wire        rstn,
    input  wire [7:0]  temp,
    input  wire [31:0] ct,
    input  wire [63:0] cl,
    output reg  [15:0] level
);
    wire [7:0]  t0 = ct[7:0],  t1 = ct[15:8], t2 = ct[23:16], t3 = ct[31:24];
    wire [15:0] l0 = cl[15:0], l1 = cl[31:16], l2 = cl[47:32], l3 = cl[63:48];

    reg [2:0]  st;
    reg [7:0]  tl, bt, nt;
    reg [15:0] bl, nl, delta;
    reg        up;
    reg [23:0] dnum;
    reg [7:0]  dden;
    wire       dstart = (st == 3'd2);
    wire       ddone, dbusy;
    wire [23:0] dq;

    div_seq #(.NW(24), .DW(8)) u_div (.clk(clk), .rstn(rstn), .start(dstart),
        .num(dnum), .den(dden), .busy(dbusy), .done(ddone), .q(dq));

    wire [15:0] qc = (dq > {8'd0, delta}) ? delta : dq[15:0];

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            st <= 3'd0; tl <= 8'd0; bt <= 8'd0; nt <= 8'd0; bl <= 16'd0; nl <= 16'd0;
            delta <= 16'd0; up <= 1'b1; dnum <= 24'd0; dden <= 8'd1; level <= 16'd0;
        end else begin
            case (st)
                3'd0: begin
                    if (temp <= t0)      level <= l0;
                    else if (temp >= t3) level <= l3;
                    else begin
                        if (temp < t1)      begin bt <= t0; nt <= t1; bl <= l0; nl <= l1; end
                        else if (temp < t2) begin bt <= t1; nt <= t2; bl <= l1; nl <= l2; end
                        else                begin bt <= t2; nt <= t3; bl <= l2; nl <= l3; end
                        tl <= temp;
                        st <= 3'd1;
                    end
                end
                3'd1: begin
                    if (nt <= bt) begin level <= nl; st <= 3'd0; end
                    else begin
                        up    <= (nl >= bl);
                        delta <= (nl >= bl) ? (nl - bl) : (bl - nl);
                        dden  <= nt - bt;
                        st    <= 3'd4;
                    end
                end
                3'd4: begin
                    dnum <= {16'd0, (tl - bt)} * {8'd0, delta};
                    st   <= 3'd2;
                end
                3'd2: st <= 3'd3;               // divider start strobe
                3'd3: if (ddone) begin
                    level <= up ? (bl + qc) : (bl - qc);
                    st    <= 3'd0;
                end
                default: st <= 3'd0;
            endcase
        end
    end
endmodule

// Bundle widths needed in module port lists (checked against fan_cfg.vh / fan_stat.vh
// inside the modules; a mismatch breaks elaboration).
`define FAN_CFG_W 641
`define FAN_ST_W  105

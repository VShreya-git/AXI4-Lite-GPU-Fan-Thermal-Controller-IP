// -----------------------------------------------------------------------------
// fan_regs : ACLK-domain register file, IRQ controller, write-lock.
//   Unmapped / read-only-written / unaligned / locked-write -> SLVERR.
//   Byte strobes honoured on every writable register.
// -----------------------------------------------------------------------------
`include "fan_defs.vh"
module fan_regs #(
    parameter NCH = 4                       // 1..8
) (
    input  wire              ACLK,
    input  wire              ARESETN,
    input  wire              wr_en,
    input  wire [7:0]        wr_addr,
    input  wire [31:0]       wr_data,
    input  wire [3:0]        wr_strb,
    output reg               wr_err,
    input  wire              rd_en,
    input  wire [7:0]        rd_addr,
    output reg  [31:0]       rd_data,
    output reg               rd_err,
    output wire [`FAN_CFG_W-1:0] cfg_bus,
    input  wire [`FAN_ST_W-1:0]  st_bus,
    output wire              irq
);
    `include "fan_cfg.vh"
    `include "fan_stat.vh"

    generate if (CFG_W != `FAN_CFG_W || ST_W != `FAN_ST_W) begin : g_width_check
        BUNDLE_WIDTH_MISMATCH_update_fan_defs_vh bad();
    end endgenerate

    localparam [31:0] ID_VALUE = 32'h4641_4E01;   // "FAN" v1

    // word indices (byte address / 4)
    localparam A_ID=0,  A_CTRL=1,  A_STATUS=2, A_IRQEN=3, A_IRQST=4, A_LOCK=5,
               A_PRESC=6, A_PERIOD=7, A_DEAD=8, A_POL=9, A_FLVL=10, A_GAMMA=11,
               A_DUTY0=12, A_PHASE0=20, A_CT=28, A_CL0=29, A_HYST=33, A_TCRIT=34,
               A_FANMIN=35, A_TEMPSW=36, A_TEMPNOW=37, A_KP=38, A_KI=39,
               A_RPMMAX=40, A_GATE=41, A_MULT=42, A_STALL=43, A_FAULTEN=44,
               A_STALETO=45, A_WDOGTO=46, A_WDOGCTL=47, A_WDOGKICK=48,
               A_FSTAT=49, A_FCLR=50, A_TCLR=51, A_RPM=52, A_DUTYNOW=53,
               A_DMIN=54, A_DMAX=55, A_FCNT=56;

    // ---------------- state ----------------
    reg [6:0]  r_ctrl;
    reg [2:0]  r_irqen, r_irqst;
    reg        r_locked;
    reg [15:0] r_presc, r_period;
    reg [7:0]  r_dead, r_pol, r_flvl, r_gamma;
    reg [15:0] r_duty  [0:7];
    reg [15:0] r_phase [0:7];
    reg [31:0] r_ct;
    reg [15:0] r_cl0, r_cl1, r_cl2, r_cl3;
    reg [7:0]  r_hyst, r_tcrit, r_tempsw;
    reg [15:0] r_fanmin, r_kp, r_ki, r_rpmmax, r_mult;
    reg [31:0] r_gate;
    reg [11:0] r_stall;
    reg [4:0]  r_faulten;
    reg [23:0] r_staleto, r_wdogto;
    reg        r_wdogen;
    reg [3:0]  r_fclr, r_kick, r_tclr;

    // ---------------- status unpack ----------------
    wire [15:0] st_rpm  = st_bus[SO_RPM  +: SW_RPM];
    wire [15:0] st_duty = st_bus[SO_DUTY +: SW_DUTY];
    wire [7:0]  st_temp = st_bus[SO_TEMP +: SW_TEMP];
    wire [7:0]  st_flt  = st_bus[SO_FLT  +: SW_FLT];
    wire [7:0]  st_fcnt = st_bus[SO_FCNT +: SW_FCNT];
    wire [15:0] st_dmin = st_bus[SO_DMIN +: SW_DMIN];
    wire [15:0] st_dmax = st_bus[SO_DMAX +: SW_DMAX];
    wire [7:0]  st_tcnt = st_bus[SO_TCNT +: SW_TCNT];
    wire [7:0]  st_pcnt = st_bus[SO_PCNT +: SW_PCNT];
    wire        st_safe = st_bus[SO_SAFE];

    // ---------------- config pack ----------------
    assign cfg_bus[CO_CTRL   +: CW_CTRL  ] = {1'b0, r_ctrl};
    assign cfg_bus[CO_PRESC  +: CW_PRESC ] = r_presc;
    assign cfg_bus[CO_PERIOD +: CW_PERIOD] = r_period;
    assign cfg_bus[CO_DEAD   +: CW_DEAD  ] = r_dead;
    assign cfg_bus[CO_POL    +: CW_POL   ] = r_pol;
    assign cfg_bus[CO_FLVL   +: CW_FLVL  ] = r_flvl;
    assign cfg_bus[CO_GAMMA  +: CW_GAMMA ] = r_gamma;
    genvar g;
    generate for (g = 0; g < 8; g = g + 1) begin : g_ch
        assign cfg_bus[CO_DUTY  + 16*g +: 16] = (g < NCH) ? r_duty[g]  : 16'd0;
        assign cfg_bus[CO_PHASE + 16*g +: 16] = (g < NCH) ? r_phase[g] : 16'd0;
    end endgenerate
    assign cfg_bus[CO_CT     +: CW_CT    ] = r_ct;
    assign cfg_bus[CO_CL     +: CW_CL    ] = {r_cl3, r_cl2, r_cl1, r_cl0};
    assign cfg_bus[CO_HYST   +: CW_HYST  ] = r_hyst;
    assign cfg_bus[CO_TCRIT  +: CW_TCRIT ] = r_tcrit;
    assign cfg_bus[CO_FANMIN +: CW_FANMIN] = r_fanmin;
    assign cfg_bus[CO_TEMPSW +: CW_TEMPSW] = r_tempsw;
    assign cfg_bus[CO_KP     +: CW_KP    ] = r_kp;
    assign cfg_bus[CO_KI     +: CW_KI    ] = r_ki;
    assign cfg_bus[CO_RPMMAX +: CW_RPMMAX] = r_rpmmax;
    assign cfg_bus[CO_GATE   +: CW_GATE  ] = r_gate;
    assign cfg_bus[CO_MULT   +: CW_MULT  ] = r_mult;
    assign cfg_bus[CO_STALL  +: CW_STALL ] = r_stall;
    assign cfg_bus[CO_FAULTEN+: CW_FAULTEN] = {3'b0, r_faulten};
    assign cfg_bus[CO_STALETO+: CW_STALETO] = r_staleto;
    assign cfg_bus[CO_WDOGTO +: CW_WDOGTO] = r_wdogto;
    assign cfg_bus[CO_WDOGEN +: CW_WDOGEN] = r_wdogen;
    assign cfg_bus[CO_CMD    +: CW_CMD   ] = {r_tclr, r_kick, r_fclr};

    // ---------------- helpers ----------------
    function [31:0] mrg;
        input [31:0] o; input [31:0] n; input [3:0] s;
        mrg = {s[3] ? n[31:24] : o[31:24], s[2] ? n[23:16] : o[23:16],
               s[1] ? n[15:8]  : o[15:8],  s[0] ? n[7:0]   : o[7:0]};
    endfunction

    // write decode: {valid, lockable}
    wire [5:0] wi = wr_addr[7:2];
    reg        w_valid, w_lockable;
    always @* begin
        w_valid = 1'b0; w_lockable = 1'b0;
        if (wr_addr[1:0] == 2'b00) begin
            case (wi)
                A_CTRL, A_IRQEN, A_IRQST, A_LOCK, A_GAMMA, A_CT, A_CL0, A_CL0+1,
                A_CL0+2, A_CL0+3, A_HYST, A_FANMIN, A_TEMPSW, A_KP, A_KI, A_RPMMAX,
                A_GATE, A_MULT, A_STALL, A_WDOGKICK, A_FCLR, A_TCLR: w_valid = 1'b1;
                A_PRESC, A_PERIOD, A_DEAD, A_POL, A_FLVL, A_TCRIT, A_FAULTEN,
                A_STALETO, A_WDOGTO, A_WDOGCTL: begin w_valid = 1'b1; w_lockable = 1'b1; end
                default: begin
                    if (wi >= A_DUTY0  && wi < A_DUTY0  + NCH) w_valid = 1'b1;
                    if (wi >= A_PHASE0 && wi < A_PHASE0 + NCH) w_valid = 1'b1;
                end
            endcase
        end
    end

    wire [7:0] lock_key = wr_data[7:0];
    wire lock_ok  = wr_strb[0] && (lock_key == 8'hA5 || lock_key == 8'h5A);
    always @* begin
        wr_err = ~w_valid | (w_lockable & r_locked);
        if (wi == A_LOCK && w_valid) wr_err = ~lock_ok;
    end

    // ---------------- IRQ events ----------------
    reg [7:0] flt_q, tcnt_q, pcnt_q;
    wire [2:0] irq_set = { (st_pcnt != pcnt_q), (st_tcnt != tcnt_q), |(st_flt & ~flt_q) };
    wire [2:0] irq_clr = (wr_en && !wr_err && wi == A_IRQST && wr_strb[0]) ? wr_data[2:0] : 3'b0;
    assign irq = |(r_irqst & r_irqen);

    integer i;
    integer j;

    always @(posedge ACLK or negedge ARESETN) begin
        if (!ARESETN) begin
            r_ctrl <= 7'd0; r_irqen <= 3'd0; r_irqst <= 3'd0; r_locked <= 1'b0;
            r_presc <= 16'd0; r_period <= 16'd1000; r_dead <= 8'd0; r_pol <= 8'd0;
            r_flvl <= 8'h01; r_gamma <= 8'd0;
            for (i = 0; i < 8; i = i + 1) begin r_duty[i] <= 16'h8000; r_phase[i] <= 16'd0; end
            r_ct <= {8'd75, 8'd60, 8'd45, 8'd30};
            r_cl0 <= 16'h4000; r_cl1 <= 16'h8000; r_cl2 <= 16'hC000; r_cl3 <= 16'hFFFF;
            r_hyst <= 8'd2; r_tcrit <= 8'd90; r_tempsw <= 8'd25;
            r_fanmin <= 16'd0; r_kp <= 16'h0200; r_ki <= 16'h0040; r_rpmmax <= 16'd5000;
            r_mult <= 16'd30; r_gate <= 32'd50_000_000; r_stall <= {4'd3, 8'h20};
            r_faulten <= 5'h1F; r_staleto <= 24'd0; r_wdogto <= 24'd0; r_wdogen <= 1'b0;
            r_fclr <= 4'd0; r_kick <= 4'd0; r_tclr <= 4'd0;
            flt_q <= 8'd0; tcnt_q <= 8'd0; pcnt_q <= 8'd0;
        end else begin
            flt_q <= st_flt; tcnt_q <= st_tcnt; pcnt_q <= st_pcnt;
            r_irqst <= (r_irqst & ~irq_clr) | irq_set;

            if (wr_en && !wr_err) begin
                case (wi)
                    A_CTRL:    r_ctrl   <= mrg({25'd0, r_ctrl}, wr_data, wr_strb);
                    A_IRQEN:   r_irqen  <= mrg({29'd0, r_irqen}, wr_data, wr_strb);
                    A_LOCK:    r_locked <= (lock_key == 8'hA5);
                    A_PRESC:   r_presc  <= mrg({16'd0, r_presc}, wr_data, wr_strb);
                    A_PERIOD:  r_period <= mrg({16'd0, r_period}, wr_data, wr_strb);
                    A_DEAD:    r_dead   <= mrg({24'd0, r_dead}, wr_data, wr_strb);
                    A_POL:     r_pol    <= mrg({24'd0, r_pol}, wr_data, wr_strb);
                    A_FLVL:    r_flvl   <= mrg({24'd0, r_flvl}, wr_data, wr_strb);
                    A_GAMMA:   r_gamma  <= mrg({24'd0, r_gamma}, wr_data, wr_strb);
                    A_CT:      r_ct     <= mrg(r_ct, wr_data, wr_strb);
                    A_CL0:     r_cl0    <= mrg({16'd0, r_cl0}, wr_data, wr_strb);
                    A_CL0+1:   r_cl1    <= mrg({16'd0, r_cl1}, wr_data, wr_strb);
                    A_CL0+2:   r_cl2    <= mrg({16'd0, r_cl2}, wr_data, wr_strb);
                    A_CL0+3:   r_cl3    <= mrg({16'd0, r_cl3}, wr_data, wr_strb);
                    A_HYST:    r_hyst   <= mrg({24'd0, r_hyst}, wr_data, wr_strb);
                    A_TCRIT:   r_tcrit  <= mrg({24'd0, r_tcrit}, wr_data, wr_strb);
                    A_FANMIN:  r_fanmin <= mrg({16'd0, r_fanmin}, wr_data, wr_strb);
                    A_TEMPSW:  r_tempsw <= mrg({24'd0, r_tempsw}, wr_data, wr_strb);
                    A_KP:      r_kp     <= mrg({16'd0, r_kp}, wr_data, wr_strb);
                    A_KI:      r_ki     <= mrg({16'd0, r_ki}, wr_data, wr_strb);
                    A_RPMMAX:  r_rpmmax <= mrg({16'd0, r_rpmmax}, wr_data, wr_strb);
                    A_GATE:    r_gate   <= mrg(r_gate, wr_data, wr_strb);
                    A_MULT:    r_mult   <= mrg({16'd0, r_mult}, wr_data, wr_strb);
                    A_STALL:   r_stall  <= mrg({20'd0, r_stall}, wr_data, wr_strb);
                    A_FAULTEN: r_faulten<= mrg({27'd0, r_faulten}, wr_data, wr_strb);
                    A_STALETO: r_staleto<= mrg({8'd0, r_staleto}, wr_data, wr_strb);
                    A_WDOGTO:  r_wdogto <= mrg({8'd0, r_wdogto}, wr_data, wr_strb);
                    A_WDOGCTL: if (wr_strb[0]) r_wdogen <= wr_data[0];
                    A_WDOGKICK: if (wr_strb[0]) r_kick <= r_kick + 4'd1;
                    A_FCLR:    if (wr_strb[0] && wr_data[0]) r_fclr <= r_fclr + 4'd1;
                    A_TCLR:    if (wr_strb[0] && wr_data[0]) r_tclr <= r_tclr + 4'd1;
                    default: begin
                        for (i = 0; i < 8; i = i + 1) begin
                            if (wi == A_DUTY0  + i) r_duty[i]  <= mrg({16'd0, r_duty[i]},  wr_data, wr_strb);
                            if (wi == A_PHASE0 + i) r_phase[i] <= mrg({16'd0, r_phase[i]}, wr_data, wr_strb);
                        end
                    end
                endcase
            end
        end
    end

    // ---------------- read mux ----------------
    wire [5:0] ri = rd_addr[7:2];
    reg [15:0] ch_rd;
    reg        ch_hit;
    always @* begin                         // per-channel DUTY/PHASE read select
        ch_rd = 16'd0; ch_hit = 1'b0;
        for (j = 0; j < 8; j = j + 1) begin
            if (ri == A_DUTY0  + j && j < NCH) begin ch_rd = r_duty[j];  ch_hit = 1'b1; end
            if (ri == A_PHASE0 + j && j < NCH) begin ch_rd = r_phase[j]; ch_hit = 1'b1; end
        end
    end

    always @* begin
        rd_data = 32'd0; rd_err = 1'b0;
        if (rd_addr[1:0] != 2'b00) rd_err = 1'b1;
        else case (ri)
            A_ID:      rd_data = ID_VALUE;
            A_CTRL:    rd_data = {25'd0, r_ctrl};
            A_STATUS:  rd_data = {29'd0, irq, r_locked, st_safe};
            A_IRQEN:   rd_data = {29'd0, r_irqen};
            A_IRQST:   rd_data = {29'd0, r_irqst};
            A_LOCK:    rd_data = {31'd0, r_locked};
            A_PRESC:   rd_data = {16'd0, r_presc};
            A_PERIOD:  rd_data = {16'd0, r_period};
            A_DEAD:    rd_data = {24'd0, r_dead};
            A_POL:     rd_data = {24'd0, r_pol};
            A_FLVL:    rd_data = {24'd0, r_flvl};
            A_GAMMA:   rd_data = {24'd0, r_gamma};
            A_CT:      rd_data = r_ct;
            A_CL0:     rd_data = {16'd0, r_cl0};
            A_CL0+1:   rd_data = {16'd0, r_cl1};
            A_CL0+2:   rd_data = {16'd0, r_cl2};
            A_CL0+3:   rd_data = {16'd0, r_cl3};
            A_HYST:    rd_data = {24'd0, r_hyst};
            A_TCRIT:   rd_data = {24'd0, r_tcrit};
            A_FANMIN:  rd_data = {16'd0, r_fanmin};
            A_TEMPSW:  rd_data = {24'd0, r_tempsw};
            A_TEMPNOW: rd_data = {24'd0, st_temp};
            A_KP:      rd_data = {16'd0, r_kp};
            A_KI:      rd_data = {16'd0, r_ki};
            A_RPMMAX:  rd_data = {16'd0, r_rpmmax};
            A_GATE:    rd_data = r_gate;
            A_MULT:    rd_data = {16'd0, r_mult};
            A_STALL:   rd_data = {20'd0, r_stall};
            A_FAULTEN: rd_data = {27'd0, r_faulten};
            A_STALETO: rd_data = {8'd0, r_staleto};
            A_WDOGTO:  rd_data = {8'd0, r_wdogto};
            A_WDOGCTL: rd_data = {31'd0, r_wdogen};
            A_FSTAT:   rd_data = {24'd0, st_flt};
            A_RPM:     rd_data = {16'd0, st_rpm};
            A_DUTYNOW: rd_data = {16'd0, st_duty};
            A_DMIN:    rd_data = {16'd0, st_dmin};
            A_DMAX:    rd_data = {16'd0, st_dmax};
            A_FCNT:    rd_data = {24'd0, st_fcnt};
            A_WDOGKICK, A_FCLR, A_TCLR: rd_data = 32'd0;
            default: begin
                rd_data = {16'd0, ch_rd};
                rd_err  = ~ch_hit;
            end
        endcase
    end
endmodule

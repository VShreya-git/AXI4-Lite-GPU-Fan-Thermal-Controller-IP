// -----------------------------------------------------------------------------
// fan_stat.vh : PCLK->ACLK status/telemetry bundle layout (single source of
// truth, included by fan_core (packs) and fan_regs (unpacks)).
// -----------------------------------------------------------------------------
/* verilator lint_off UNUSEDPARAM */
localparam SW_RPM  = 16;
localparam SW_DUTY = 16;
localparam SW_TEMP = 8;
localparam SW_FLT  = 8;
localparam SW_FCNT = 8;
localparam SW_DMIN = 16;
localparam SW_DMAX = 16;
localparam SW_TCNT = 8;    // increments on every tach window completion
localparam SW_PCNT = 8;    // increments on every PWM frame
localparam SW_SAFE = 1;

localparam SO_RPM  = 0;
localparam SO_DUTY = SO_RPM  + SW_RPM;
localparam SO_TEMP = SO_DUTY + SW_DUTY;
localparam SO_FLT  = SO_TEMP + SW_TEMP;
localparam SO_FCNT = SO_FLT  + SW_FLT;
localparam SO_DMIN = SO_FCNT + SW_FCNT;
localparam SO_DMAX = SO_DMIN + SW_DMIN;
localparam SO_TCNT = SO_DMAX + SW_DMAX;
localparam SO_PCNT = SO_TCNT + SW_TCNT;
localparam SO_SAFE = SO_PCNT + SW_PCNT;
localparam ST_W    = SO_SAFE + SW_SAFE;
/* verilator lint_on UNUSEDPARAM */

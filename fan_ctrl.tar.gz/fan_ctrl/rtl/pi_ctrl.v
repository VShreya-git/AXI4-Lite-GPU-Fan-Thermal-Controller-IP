// -----------------------------------------------------------------------------
// pi_ctrl : fixed-point PI controller, update on 'update' pulse.
//   e  = target - meas                      (signed, RPM)
//   u  = Kp*e + I,  I += Ki*e               (Kp,Ki unsigned Q8.8)
//   output clamped to 0..0xFFFF (fractional duty).
//   Anti-windup: conditional integration (I frozen while saturated in the
//   direction of the error) + I clamped to the output range.
//   Bumpless transfer: while !en, I and u track 'preload'.
// -----------------------------------------------------------------------------
module pi_ctrl (
    input  wire        clk,
    input  wire        rstn,
    input  wire        en,
    input  wire        update,
    input  wire [15:0] target,
    input  wire [15:0] meas,
    input  wire [15:0] kp,
    input  wire [15:0] ki,
    input  wire [15:0] preload,
    output reg  [15:0] u
);
    reg  signed [34:0] iacc;
    wire signed [17:0] e    = $signed({2'b00, target}) - $signed({2'b00, meas});
    wire signed [34:0] pm   = e * $signed({1'b0, kp});
    wire signed [34:0] im   = e * $signed({1'b0, ki});
    wire signed [34:0] pt   = pm >>> 8;
    wire signed [34:0] it   = im >>> 8;
    wire signed [34:0] inew = iacc + it;
    wire signed [34:0] uraw = pt + inew;
    wire hi   = (uraw > 35'sd65535);
    wire lo   = (uraw < 35'sd0);
    wire stop = (hi && (e > 18'sd0)) || (lo && (e < 18'sd0));
    wire signed [34:0] iclamp = (inew < 35'sd0) ? 35'sd0 :
                                (inew > 35'sd65535) ? 35'sd65535 : inew;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            iacc <= 35'sd0; u <= 16'd0;
        end else if (!en) begin
            iacc <= $signed({19'd0, preload}); u <= preload;
        end else if (update) begin
            if (!stop) iacc <= iclamp;
            u <= hi ? 16'hFFFF : (lo ? 16'h0000 : uraw[15:0]);
        end
    end
endmodule

// Single-cycle pulse CDC (toggle synchronizer).
// Pulses must be spaced by > ~3 destination clock cycles or they coalesce.
module pulse_sync (
    input  wire src_clk,
    input  wire src_rst_n,
    input  wire src_pulse,
    input  wire dst_clk,
    input  wire dst_rst_n,
    output wire dst_pulse
);
    reg tog;
    always @(posedge src_clk) begin
        if (!src_rst_n)    tog <= 1'b0;
        else if (src_pulse) tog <= ~tog;
    end

    wire tog_d;
    sync2 #(.W(1)) u_s (.clk(dst_clk), .rst_n(dst_rst_n), .d(tog), .q(tog_d));

    reg tog_q;
    always @(posedge dst_clk) begin
        if (!dst_rst_n) tog_q <= 1'b0;
        else            tog_q <= tog_d;
    end
    assign dst_pulse = tog_d ^ tog_q;
endmodule

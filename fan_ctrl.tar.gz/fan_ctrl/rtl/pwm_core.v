// -----------------------------------------------------------------------------
// pwm_core : multi-channel PWM, shared time base (PCLK domain).
//   * 16-bit prescaler, 16-bit period (clamped to >=2), 16-bit FRACTIONAL duty
//     (0x0000 = 0 %, 0xFFFF = exactly 100 %).  Duty is period-independent.
//   * Shadow registers: every parameter is latched only at a frame boundary
//     (or while disabled) -> no runt pulses on live updates.
//   * Edge-aligned (per-channel phase offset) or center-aligned (up/down).
//   * Optional gamma (x^2) per channel; polarity per channel.
//   * Complementary pairs (0,1) (2,3)... with exact dead-time insertion
//     (both outputs low for DEAD PCLK cycles at every transition).
//   * 'safe' forces every pin to its FLVL level (registered output, 1 flop).
//   * External sync input restarts the frame; frame_start pulse = ADC trigger.
// Pin = polarity XOR raw; disabled -> raw=0 (pin sits at its polarity level).
// -----------------------------------------------------------------------------
module pwm_core #(
    parameter NCH = 4
) (
    input  wire             clk,
    input  wire             rstn,
    input  wire             en,
    input  wire             center,
    input  wire             comp_en,
    input  wire [15:0]      prescale,
    input  wire [15:0]      period,
    input  wire [7:0]       dead,
    input  wire [7:0]       pol,
    input  wire [7:0]       flvl,
    input  wire [7:0]       gamma_en,
    input  wire [127:0]     duty_f,
    input  wire [127:0]     phase_f,
    input  wire             safe,
    input  wire             sync_in,
    input  wire             sync_en,
    output reg  [NCH-1:0]   pwm,
    output reg              frame_start
);
    reg  [15:0] psc_cnt, cnt;
    reg         dir, sync_q;
    reg  [15:0] s_presc, s_period;
    reg         s_center, s_comp;
    reg  [7:0]  s_dead, s_pol;

    wire [15:0] per_live = (period < 16'd2) ? 16'd2 : period;
    wire [15:0] last     = s_period - 16'd1;
    wire        tick     = (psc_cnt >= s_presc);
    wire        at_end   = tick & (s_center ? (dir & (cnt == 16'd0)) : (cnt == last));
    wire        load     = ~en | (en & at_end);
    wire        sync_pls = sync_en & sync_in & ~sync_q;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            psc_cnt <= 16'd0; cnt <= 16'd0; dir <= 1'b0; sync_q <= 1'b0;
            frame_start <= 1'b0;
            s_presc <= 16'd0; s_period <= 16'd2; s_center <= 1'b0; s_comp <= 1'b0;
            s_dead <= 8'd0; s_pol <= 8'd0;
        end else begin
            sync_q      <= sync_in;
            frame_start <= en & at_end;
            if (!en || sync_pls) begin
                psc_cnt <= 16'd0; cnt <= 16'd0; dir <= 1'b0;
            end else if (tick) begin
                psc_cnt <= 16'd0;
                if (at_end) begin
                    cnt <= 16'd0; dir <= 1'b0;
                end else if (s_center) begin
                    if (!dir) begin
                        if (cnt == last) dir <= 1'b1; else cnt <= cnt + 16'd1;
                    end else cnt <= cnt - 16'd1;
                end else cnt <= cnt + 16'd1;
            end else begin
                psc_cnt <= psc_cnt + 16'd1;
            end
            if (load) begin
                s_presc <= prescale; s_period <= per_live; s_center <= center;
                s_comp <= comp_en;   s_dead <= dead;       s_pol <= pol;
            end
        end
    end

    // ---------------- per channel compare ----------------
    wire [NCH-1:0] raw;
    genvar n, k;
    generate for (n = 0; n < NCH; n = n + 1) begin : g_ch
        wire [15:0] d    = duty_f[16*n +: 16];
        wire [31:0] dsq  = d * d;
        wire [15:0] gd   = gamma_en[n] ? ((d == 16'hFFFF) ? 16'hFFFF : dsq[31:16]) : d;
        wire [31:0] prod = gd * per_live;
        wire [15:0] dc   = (gd == 16'hFFFF) ? per_live : prod[31:16];
        wire [15:0] ph_i = phase_f[16*n +: 16];
        wire [15:0] ph   = (ph_i >= per_live) ? (per_live - 16'd1) : ph_i;
        reg  [15:0] s_dcnt, s_ph;
        always @(posedge clk or negedge rstn) begin
            if (!rstn) begin s_dcnt <= 16'd0; s_ph <= 16'd0; end
            else if (load) begin s_dcnt <= dc; s_ph <= ph; end
        end
        wire [16:0] sum = {1'b0, cnt} + {1'b0, s_ph};
        wire [16:0] wrp = (sum >= {1'b0, s_period}) ? (sum - {1'b0, s_period}) : sum;
        wire [15:0] cc  = s_center ? cnt : wrp[15:0];
        assign raw[n] = (cc < s_dcnt);
    end endgenerate

    // ---------------- complementary pairs + dead time ----------------
    wire [NCH-1:0] hs, ls;
    generate for (k = 0; k < NCH; k = k + 1) begin : g_pair
        if (k < NCH/2) begin : g_real
            localparam S_HS = 2'd0, S_LS = 2'd1, S_DEAD = 2'd2;
            reg [1:0] st;
            reg [7:0] dtc;
            wire r = raw[2*k];
            always @(posedge clk or negedge rstn) begin
                if (!rstn) begin st <= S_LS; dtc <= 8'd0; end
                else if (!en || !s_comp) begin st <= S_LS; dtc <= 8'd0; end
                else case (st)
                    S_HS:   if (!r) begin
                                if (s_dead == 8'd0) st <= S_LS;
                                else begin st <= S_DEAD; dtc <= s_dead - 8'd1; end
                            end
                    S_LS:   if (r) begin
                                if (s_dead == 8'd0) st <= S_HS;
                                else begin st <= S_DEAD; dtc <= s_dead - 8'd1; end
                            end
                    S_DEAD: if (dtc == 8'd0) st <= r ? S_HS : S_LS;
                            else dtc <= dtc - 8'd1;
                    default: st <= S_LS;
                endcase
            end
            assign hs[k] = (st == S_HS);
            assign ls[k] = (st == S_LS);
        end else begin : g_none
            assign hs[k] = 1'b0;
            assign ls[k] = 1'b0;
        end
    end endgenerate

    // ---------------- output stage ----------------
    wire [NCH-1:0] pre;
    generate for (n = 0; n < NCH; n = n + 1) begin : g_pre
        if ((n % 2 == 1) || (n + 1 < NCH)) begin : g_paired
            assign pre[n] = !en ? 1'b0 :
                            s_comp ? ((n % 2 == 0) ? hs[n/2] : ls[n/2]) : raw[n];
        end else begin : g_single
            assign pre[n] = !en ? 1'b0 : raw[n];
        end
    end endgenerate

    wire [NCH-1:0] pin_d = safe ? flvl[NCH-1:0] : (pre ^ s_pol[NCH-1:0]);
    always @(posedge clk or negedge rstn) begin
        if (!rstn) pwm <= {NCH{1'b0}};
        else       pwm <= pin_d;
    end
endmodule

// -----------------------------------------------------------------------------
// reset_sync : asynchronous-assert, synchronous-deassert reset synchronizer.
//   arstn  : external asynchronous active-low reset
//   srstn  : reset released synchronously to 'clk' (2 clock edges after arstn)
// -----------------------------------------------------------------------------
module reset_sync (
    input  wire clk,
    input  wire arstn,
    output wire srstn
);
    (* ASYNC_REG = "TRUE" *) reg [1:0] sr;

    always @(posedge clk or negedge arstn) begin
        if (!arstn) sr <= 2'b00;
        else        sr <= {sr[0], 1'b1};
    end

    assign srstn = sr[1];
endmodule

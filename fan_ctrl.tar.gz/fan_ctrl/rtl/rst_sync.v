// Reset synchronizer: asynchronous assert, synchronous de-assert.
module rst_sync (
    input  wire clk,
    input  wire arst_n,   // asynchronous active-low reset in
    output wire rst_n     // active-low reset, de-asserted synchronously to clk
);
    reg [1:0] s;
    always @(posedge clk or negedge arst_n) begin
        if (!arst_n) s <= 2'b00;
        else         s <= {s[0], 1'b1};
    end
    assign rst_n = s[1];
endmodule

// -----------------------------------------------------------------------------
// safety_ctrl : sticky fault latch, watchdog, stale-sensor timeout.
//   fault bits: [0] external pin  [1] fan stall  [2] stale sensor
//               [3] watchdog      [4] over-temperature
//   A fault is latched only if enabled in fault_en; 'clr' re-evaluates (a cause
//   that is still present re-latches immediately).  'safe' is registered.
// -----------------------------------------------------------------------------
module safety_ctrl (
    input  wire        clk,
    input  wire        rstn,
    input  wire        pin_c,
    input  wire        stall_c,
    input  wire        overtemp_c,
    input  wire        hw_temp,        // stale check only for the hardware sensor
    input  wire        temp_valid,
    input  wire [23:0] stale_to,
    input  wire        wdog_en,
    input  wire [23:0] wdog_to,
    input  wire        kick,
    input  wire [4:0]  fault_en,
    input  wire        clr,
    input  wire        tele_clr,
    output reg  [4:0]  lat,
    output reg         safe,
    output reg  [7:0]  fcnt
);
    reg [23:0] stale_cnt, wd_cnt;
    wire stale_c = hw_temp && (stale_to != 24'd0) && (stale_cnt >= stale_to);
    wire wd_c    = wdog_en && (wdog_to  != 24'd0) && (wd_cnt    >= wdog_to);
    wire [4:0] cause = {overtemp_c, wd_c, stale_c, stall_c, pin_c};
    wire [4:0] nxt   = (clr ? 5'd0 : lat) | (cause & fault_en);
    wire [4:0] newf  = nxt & ~lat;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            lat <= 5'd0; safe <= 1'b0; fcnt <= 8'd0; stale_cnt <= 24'd0; wd_cnt <= 24'd0;
        end else begin
            lat  <= nxt;
            safe <= |nxt;
            if (tele_clr) fcnt <= 8'd0;
            else if ((|newf) && fcnt != 8'hFF) fcnt <= fcnt + 8'd1;

            if (temp_valid || !hw_temp) stale_cnt <= 24'd0;
            else if (stale_cnt != 24'hFFFFFF) stale_cnt <= stale_cnt + 24'd1;

            if (!wdog_en || kick) wd_cnt <= 24'd0;
            else if (wd_cnt != 24'hFFFFFF) wd_cnt <= wd_cnt + 24'd1;
        end
    end
endmodule

// Two-flop synchronizer for single-bit (or independent multi-bit, gray/level)
// signals crossing into clk's domain. Do NOT use for related multi-bit buses.
module sync2 #(
    parameter W         = 1,
    parameter RESET_VAL = 0
) (
    input  wire         clk,
    input  wire         rst_n,
    input  wire [W-1:0] d,
    output wire [W-1:0] q
);
    (* ASYNC_REG = "TRUE" *) reg [W-1:0] m;
    (* ASYNC_REG = "TRUE" *) reg [W-1:0] s;
    always @(posedge clk) begin
        if (!rst_n) begin
            m <= RESET_VAL[W-1:0];
            s <= RESET_VAL[W-1:0];
        end else begin
            m <= d;
            s <= m;
        end
    end
    assign q = s;
endmodule

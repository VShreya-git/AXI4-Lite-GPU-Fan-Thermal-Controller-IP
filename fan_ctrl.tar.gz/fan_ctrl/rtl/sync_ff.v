// -----------------------------------------------------------------------------
// sync_ff : N-stage flip-flop synchronizer for a SINGLE-BIT asynchronous signal.
//   * Use only for 1-bit level signals or toggle signals (never for buses).
//   * Async reset to RESET_VAL; the reset must itself be deasserted
//     synchronously to 'clk' (see reset_sync).
// -----------------------------------------------------------------------------
module sync_ff #(
    parameter STAGES    = 2,
    parameter RESET_VAL = 1'b0
) (
    input  wire clk,
    input  wire rstn,
    input  wire d,
    output wire q
);
    (* ASYNC_REG = "TRUE" *) reg [STAGES-1:0] sr;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) sr <= {STAGES{RESET_VAL}};
        else       sr <= {sr[STAGES-2:0], d};
    end

    assign q = sr[STAGES-1];
endmodule

// -----------------------------------------------------------------------------
// tach_capture : counts tach pulses over a programmable gate window.
//   rpm = pulses * mult (saturating 16 bit).   e.g. 1 s gate, 2 pulses/rev
//   -> mult = 30.   'valid' pulses when a window completes.
// -----------------------------------------------------------------------------
module tach_capture (
    input  wire        clk,
    input  wire        rstn,
    input  wire        tach_in,        // asynchronous
    input  wire [31:0] gate,           // window length in PCLK cycles (<2 = off)
    input  wire [15:0] mult,
    output reg  [15:0] rpm,
    output reg         valid,
    output reg         zero_win,       // last window had no pulses
    output reg  [7:0]  win_cnt
);
    wire ts;
    sync_ff #(.STAGES(2)) u_s (.clk(clk), .rstn(rstn), .d(tach_in), .q(ts));
    reg tq;
    wire edge_p = ts & ~tq;

    reg  [31:0] gcnt;
    reg  [15:0] pcnt;
    wire [15:0] pn   = (pcnt == 16'hFFFF) ? pcnt : (pcnt + {15'd0, edge_p});
    wire [31:0] prod = pn * mult;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            tq <= 1'b0; gcnt <= 32'd0; pcnt <= 16'd0; rpm <= 16'd0;
            valid <= 1'b0; zero_win <= 1'b0; win_cnt <= 8'd0;
        end else begin
            tq    <= ts;
            valid <= 1'b0;
            if (gate < 32'd2) begin
                gcnt <= 32'd0; pcnt <= 16'd0;
            end else if (gcnt >= gate - 32'd1) begin
                gcnt     <= 32'd0;
                pcnt     <= 16'd0;
                valid    <= 1'b1;
                zero_win <= (pn == 16'd0);
                rpm      <= (prod[31:16] != 16'd0) ? 16'hFFFF : prod[15:0];
                win_cnt  <= win_cnt + 8'd1;
            end else begin
                gcnt <= gcnt + 32'd1;
                pcnt <= pn;
            end
        end
    end
endmodule

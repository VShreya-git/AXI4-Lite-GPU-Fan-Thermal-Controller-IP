// Software watchdog (ACLK domain). Timeout is in units of 1024 ACLK cycles.
// tmo == 0 disables it. A kick clears the counter and the expired flag.
module wdog (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [15:0] tmo,
    input  wire        kick,
    output reg         expired,      // level, stays set until kicked
    output wire        expire_pulse  // one cycle when it first expires
);
    reg [9:0]  pre;
    reg [15:0] units;
    reg        expired_d;

    always @(posedge clk) begin
        if (!rst_n) begin
            pre       <= 10'd0;
            units     <= 16'd0;
            expired   <= 1'b0;
            expired_d <= 1'b0;
        end else begin
            expired_d <= expired;
            if (kick || tmo == 16'd0) begin
                pre     <= 10'd0;
                units   <= 16'd0;
                expired <= 1'b0;
            end else if (!expired) begin
                pre <= pre + 10'd1;
                if (pre == 10'd1023) begin
                    units <= units + 16'd1;
                    if (units + 16'd1 >= tmo)
                        expired <= 1'b1;
                end
            end
        end
    end
    assign expire_pulse = expired & ~expired_d;
endmodule

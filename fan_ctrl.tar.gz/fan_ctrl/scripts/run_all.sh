#!/bin/bash
# Full regression: lint -> unit tests -> system test -> synthesis [-> bug injection]
#   ./scripts/run_all.sh          (fast)      ./scripts/run_all.sh --mutate
set -e
cd "$(dirname "$0")/.."
mkdir -p build
RTL="rtl/sync_ff.v rtl/reset_sync.v rtl/cdc_bus_hs.v rtl/axi4l_slave_if.v rtl/fan_regs.v rtl/pwm_core.v rtl/tach_capture.v rtl/div_seq.v rtl/fan_curve.v rtl/pi_ctrl.v rtl/safety_ctrl.v rtl/fan_core.v rtl/fan_ctrl_top.v"

echo "== Verilator lint =="
verilator --lint-only -Wall -Wno-DECLFILENAME -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM \
  -Wno-WIDTHTRUNC -Wno-WIDTHEXPAND -Wno-PINCONNECTEMPTY -Irtl $RTL --top-module fan_ctrl_top && echo "lint clean"

echo "== tb_pwm_core (reference-model compare) =="
iverilog -g2005 -I rtl -o build/tb_pwm.vvp tb/tb_pwm_core.v rtl/pwm_core.v && vvp build/tb_pwm.vvp | grep -E "^\[pwm\]|TB_PWM"

echo "== tb_cdc =="
iverilog -g2005 -I rtl -o build/tb_cdc.vvp tb/tb_cdc.v rtl/cdc_bus_hs.v rtl/sync_ff.v && vvp build/tb_cdc.vvp | grep -E "^\[cdc\]|TB_CDC"

echo "== tb_system (full chip) =="
iverilog -g2005 -I rtl -o build/tb_sys.vvp tb/tb_system.v $RTL -s tb_system && vvp build/tb_sys.vvp | grep -v finish

echo "== Yosys synthesis =="
yosys -q -l build/synth.log scripts/synth.ys
echo "latch cells: $(grep -c '^Latch inferred' build/synth.log)"; grep -E "Number of cells" build/synth_stat.txt

if [ "$1" == "--mutate" ]; then python3 scripts/mutate.py 4; fi

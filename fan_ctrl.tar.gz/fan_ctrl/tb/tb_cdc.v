`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// tb_cdc : stress test of cdc_bus_hs.  The source bus is changed EVERY source
// clock (worst case).  Checks (white-box):
//   * every captured word equals the held snapshot (coherent, never torn/live)
//   * the snapshot is not modified while a transfer is in flight
//   * after the source goes quiet, the destination converges to the source
// Run for several clock ratios.
// -----------------------------------------------------------------------------
module tb_cdc;
    reg sclk = 0, dclk = 0, rstn = 0;
    real SP = 10.0, DP = 13.0;
    always #(SP/2) sclk = ~sclk;
    always #(DP/2) dclk = ~dclk;

    reg  [31:0] src_data = 0;
    wire [31:0] dst_data;
    wire        dst_valid;
    cdc_bus_hs #(.W(32)) dut (.src_clk(sclk), .src_rstn(rstn), .src_data(src_data),
        .dst_clk(dclk), .dst_rstn(rstn), .dst_data(dst_data), .dst_valid(dst_valid));

    integer errors = 0, xfers = 0, run;
    reg [31:0] hold_snap; reg busy_q = 0;
    reg [31:0] exp_cap;
    always @(posedge dclk) if (rstn && (dut.req_s !== dut.ack_t)) begin
        exp_cap = dut.hold;                 // value the destination is about to sample
        xfers = xfers + 1;
        #1;
        if (dst_data !== exp_cap) begin errors = errors + 1; if (errors < 5) $display("CDC: captured word != held snapshot"); end
    end
    // hold must be stable while busy
    always @(posedge sclk) if (rstn) begin
        if (busy_q && dut.busy && dut.hold !== hold_snap) begin errors = errors + 1; $display("CDC: hold changed in flight"); end
        busy_q <= dut.busy; hold_snap <= dut.hold;
    end
    always @(posedge sclk) if (rstn && run) src_data <= $urandom;

    integer r;
    initial begin
        run = 0;
        for (r = 0; r < 3; r = r + 1) begin
            rstn = 0; src_data = 0; run = 0;
            case (r) 0: DP = 13.0; 1: DP = 3.7; default: DP = 47.0; endcase
            #100 rstn = 1;
            #50 run = 1;
            repeat (3000) @(posedge sclk);
            run = 0;
            repeat (200) @(posedge sclk);
            if (dst_data !== src_data) begin errors = errors + 1; $display("CDC: no convergence (dst=%h src=%h)", dst_data, src_data); end
        end
        $display("[cdc] %0d transfers observed", xfers);
        if (xfers < 100) errors = errors + 1;
        $display("TB_CDC: %0s (errors=%0d)", errors == 0 ? "PASS" : "FAIL", errors);
        $finish;
    end
endmodule

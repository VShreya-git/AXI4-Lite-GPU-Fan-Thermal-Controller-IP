`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// tb_pwm_core : self-checking randomized test of pwm_core against an
// INDEPENDENT position-based reference model (computes the counter value
// arithmetically from a tick index instead of counting like the RTL).
// Also checks dead-time insertion (exact gap, no overlap), safe override and
// the sync input.
// -----------------------------------------------------------------------------
module tb_pwm_core;
    localparam NCH = 4;
    reg clk = 0;
    always #5 clk = ~clk;

    reg rstn = 0;
    reg en = 0, center = 0, comp_en = 0, safe = 0, sync_in = 0, sync_en = 0;
    reg [15:0] prescale = 0, period = 10;
    reg [7:0]  dead = 0, pol = 0, flvl = 8'h01, gamma_en = 0;
    reg [127:0] duty_f = 0, phase_f = 0;
    wire [NCH-1:0] pwm;
    wire frame_start;

    pwm_core #(.NCH(NCH)) dut (.clk(clk), .rstn(rstn), .en(en), .center(center),
        .comp_en(comp_en), .prescale(prescale), .period(period), .dead(dead),
        .pol(pol), .flvl(flvl), .gamma_en(gamma_en), .duty_f(duty_f), .phase_f(phase_f),
        .safe(safe), .sync_in(sync_in), .sync_en(sync_en), .pwm(pwm), .frame_start(frame_start));

    integer errors = 0, checks = 0;

    // ---------------- reference model ----------------
    integer m_psc, m_t, m_P, m_presc, m_center;
    integer m_pol;
    integer m_dc [0:NCH-1];
    integer m_ph [0:NCH-1];
    reg [NCH-1:0] exp_pin;
    integer n, cnt_v, cc, ph, perl, u;
    reg [63:0] g, d;
    reg model_on;

    task model_load;
        begin
            perl = (period < 2) ? 2 : period;
            m_P = perl; m_presc = prescale; m_center = center; m_pol = pol;
            for (n = 0; n < NCH; n = n + 1) begin
                d = duty_f[16*n +: 16];
                if (gamma_en[n]) g = (d == 65535) ? 65535 : (d * d) / 65536; else g = d;
                m_dc[n] = (g == 65535) ? perl : ((g * perl) / 65536);
                ph = phase_f[16*n +: 16];
                m_ph[n] = (ph >= perl) ? perl - 1 : ph;
            end
        end
    endtask

    reg tick_m, end_m;
    always @(posedge clk) begin
        if (!rstn) begin
            m_psc = 0; m_t = 0; m_P = 2; m_presc = 0; m_center = 0; m_pol = 0;
            for (n = 0; n < NCH; n = n + 1) begin m_dc[n] = 0; m_ph[n] = 0; end
            exp_pin = 0;
        end else begin
            // expected pin value from PRE-edge state (RTL registers its output)
            for (n = 0; n < NCH; n = n + 1) begin
                if (m_center) begin
                    cnt_v = (m_t < m_P) ? m_t : (2*m_P - 1 - m_t);
                    cc = cnt_v;
                end else begin
                    cc = (m_t + m_ph[n]) % m_P;
                end
                if (safe) exp_pin[n] = flvl[n];
                else exp_pin[n] = ((en && (cc < m_dc[n])) ? 1'b1 : 1'b0) ^ m_pol[n];
            end
            // advance
            if (!en) begin
                m_psc = 0; m_t = 0; model_load;
            end else begin
                tick_m = (m_psc >= m_presc);
                end_m  = tick_m && (m_t == (m_center ? 2*m_P - 1 : m_P - 1));
                if (tick_m) begin m_psc = 0; m_t = end_m ? 0 : m_t + 1; end
                else m_psc = m_psc + 1;
                if (end_m) model_load;
            end
        end
    end

    reg cmp_on = 0;
    always @(negedge clk) if (cmp_on && model_on) begin
        checks = checks + 1;
        if (pwm !== exp_pin) begin
            errors = errors + 1;
            if (errors < 4) $display("[%0t] MISMATCH pwm=%b exp=%b P=%0d center=%0d en=%b pol=%b gam=%b duty=%h dc3=%0d t=%0d sdcnt3=%0d s_pol=%b", $time, pwm, exp_pin, m_P, m_center, en, pol, gamma_en, duty_f[63:48], m_dc[3], m_t, dut.g_ch[3].s_dcnt, dut.s_pol);
        end
    end

    // ---------------- random stimulus ----------------
    integer trial, k, fr;
    reg [15:0] rd;
    function [15:0] rnd_duty;
        input integer dummy;
        integer r;
        begin
            r = $urandom % 8;
            if (r == 0) rnd_duty = 16'h0000;
            else if (r == 1) rnd_duty = 16'hFFFF;
            else rnd_duty = $urandom;
        end
    endfunction

    task rand_cfg;
        integer i;
        begin
            period  = ($urandom % 3 == 0) ? ($urandom % 4) : (2 + $urandom % 40);
            prescale= $urandom % 4;
            center  = $urandom;
            pol     = $urandom;
            gamma_en= $urandom;
            for (i = 0; i < 4; i = i + 1) begin
                duty_f[16*i +: 16]  = rnd_duty(0);
                phase_f[16*i +: 16] = ($urandom % 3 == 0) ? 16'hFFFF : ($urandom % 50);
            end
        end
    endtask

    // ---------------- dead-time monitor ----------------
    reg dt_mon = 0;
    integer gap_run = 0, seen_hs = 0, dt_errors = 0, gaps_checked = 0, overlap = 0;
    always @(negedge clk) if (dt_mon) begin
        if (pwm[0] & pwm[1]) overlap = overlap + 1;
        if (pwm[0] | pwm[1]) begin
            if (seen_hs && gap_run != 0) begin
                gaps_checked = gaps_checked + 1;
                if (gap_run != dead) dt_errors = dt_errors + 1;
            end
            gap_run = 0; seen_hs = 1;
        end else gap_run = gap_run + 1;
    end

    integer lat;
    initial begin
        model_on = 0;
        #1 rstn = 0;
        repeat (4) @(negedge clk);
        rstn = 1;
        repeat (2) @(negedge clk);
        model_on = 1; cmp_on = 1;

        // ---- 1. random configs, live updates, safe toggles ----
        for (trial = 0; trial < 300; trial = trial + 1) begin
            @(negedge clk); en = 0; rand_cfg;
            repeat (3) @(negedge clk);
            en = 1;
            for (fr = 0; fr < 6; fr = fr + 1) begin
                repeat (1 + $urandom % 60) @(negedge clk);
                // live update mid-frame (exercises shadow registers)
                if ($urandom % 2) begin
                    duty_f[15:0] = rnd_duty(0); duty_f[63:48] = rnd_duty(0);
                    if ($urandom % 3 == 0) period = 2 + $urandom % 40;
                    if ($urandom % 4 == 0) center = $urandom;
                end
                if ($urandom % 8 == 0) safe = 1; else safe = 0;
            end
            safe = 0;
        end
        cmp_on = 0;
        $display("[pwm] random model compare: %0d cycle checks, %0d mismatches", checks, errors);

        // ---- 2. 100 % / 0 % exactness ----
        @(negedge clk); en = 0; center = 0; prescale = 0; period = 37; pol = 0; gamma_en = 0; safe = 0;
        duty_f = {NCH{16'hFFFF}}; phase_f = 0;
        repeat (3) @(negedge clk); en = 1; repeat (3) @(negedge clk);
        begin : full_duty
            integer hi; hi = 0;
            for (k = 0; k < 37*10; k = k + 1) begin @(negedge clk); hi = hi + pwm[0]; end
            if (hi !== 370) begin errors = errors + 1; $display("100%% duty not exact: %0d/370", hi); end
        end
        duty_f = 0; repeat (200) @(negedge clk);
        begin : zero_duty
            integer hi; hi = 0;
            for (k = 0; k < 370; k = k + 1) begin @(negedge clk); hi = hi + pwm[0]; end
            if (hi !== 0) begin errors = errors + 1; $display("0%% duty not exact: %0d", hi); end
        end

        // ---- 3. complementary + dead time (edge and center) ----
        for (k = 0; k < 2; k = k + 1) begin
            @(negedge clk); en = 0; center = k; comp_en = 1; dead = 6; period = 40; prescale = 0;
            duty_f = {NCH{16'h6000}}; pol = 0;
            repeat (3) @(negedge clk); en = 1; dt_mon = 0; seen_hs = 0; gap_run = 0;
            repeat (100) @(negedge clk);
            dt_mon = 1; repeat (4000) @(negedge clk); dt_mon = 0;
            $display("[pwm] dead-time (center=%0d): %0d gaps checked, %0d wrong, %0d overlaps", k, gaps_checked, dt_errors, overlap);
            if (dt_errors != 0 || overlap != 0 || gaps_checked < 50) errors = errors + 1;
            gaps_checked = 0; dt_errors = 0; overlap = 0;
            // 0 % and 100 % with dead time: LS fully on / HS fully on
            duty_f = 0; repeat (400) @(negedge clk);
            if (pwm[0] !== 1'b0 || pwm[1] !== 1'b1) begin errors = errors + 1; $display("comp 0%% wrong"); end
            duty_f = {NCH{16'hFFFF}}; repeat (400) @(negedge clk);
            if (pwm[0] !== 1'b1 || pwm[1] !== 1'b0) begin errors = errors + 1; $display("comp 100%% wrong"); end
        end
        comp_en = 0;

        // ---- 4. safe override latency + levels ----
        @(negedge clk); en = 1; duty_f = 0; pol = 0; flvl = 8'b0101; center = 0; period = 50;
        repeat (200) @(negedge clk);
        @(negedge clk); safe = 1; lat = 0;
        while (pwm !== 4'b0101 && lat < 10) begin @(negedge clk); lat = lat + 1; end
        $display("[pwm] safe -> pins forced in %0d cycle(s) after safe asserted (pins=%b)", lat+1, pwm);
        if (pwm !== 4'b0101 || lat > 1) errors = errors + 1;
        @(negedge clk); safe = 0;

        // ---- 5. sync input restarts the frame ----
        @(negedge clk); en = 1; sync_en = 1; period = 100; duty_f = {NCH{16'h8000}}; flvl = 0; pol = 0; phase_f = 0;
        repeat (250) @(negedge clk);
        begin : sync_chk
            integer fs_seen;
            fs_seen = 0;
            @(negedge clk); sync_in = 1; @(negedge clk); sync_in = 0;
            // after sync the counter restarts at 0: first 50 cycles high (+pipeline)
            repeat (3) @(negedge clk);
            if (pwm[0] !== 1'b1) begin errors = errors + 1; $display("sync did not restart frame"); end
        end

        $display("TB_PWM: %0s  (errors=%0d, model checks=%0d)", (errors == 0) ? "PASS" : "FAIL", errors, checks);
        $finish;
    end
endmodule
